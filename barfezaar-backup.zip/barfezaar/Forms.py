from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, FileField, BooleanField, TextAreaField, FloatField, IntegerField, RadioField, SelectMultipleField, widgets, SelectField, DateTimeField
from wtforms.validators import DataRequired, Length, EqualTo, Regexp, ValidationError, Email, NumberRange, Optional
from email_validator import validate_email, EmailNotValidError
from Models import User, Product
from datetime import datetime

class RegistrationForm(FlaskForm):
    username = StringField(
        "Username", validators=[DataRequired(), Length(min=2, max=20)]
    )
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    confirm_password = PasswordField(
        "Confirm Password", validators=[DataRequired(), EqualTo("password")]
    )
    mobile_number = StringField("Mobile Number", validators=[DataRequired()])
    submit = SubmitField("Sign Up")

    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError("Please use a different username.")

    def validate_email(self, email):
        # First, check if the email is already registered
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError("Please use a different email address.")

        # Second, validate email format using email_validator library
        try:
            validate_email(email.data)
        except EmailNotValidError as e:
            raise ValidationError(str(e))

class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])
    remember_me = BooleanField("Remember Me")
    submit = SubmitField("Sign In")

class OTPForm(FlaskForm):
    otp = StringField(
        "OTP",
        validators=[
            DataRequired(),
            Length(min=6, max=6, message="OTP must be 6 digits long."),
        ],
    )
    submit = SubmitField("Verify OTP")

class FeedbackForm(FlaskForm):
    content = TextAreaField("Content", validators=[DataRequired()])
    rating_value = IntegerField("Rating", validators=[DataRequired()])
    submit = SubmitField("Submit")

class EditProfileForm(FlaskForm):
    username = StringField(
        "Username", validators=[DataRequired(), Length(min=4, max=20)]
    )
    email = StringField("Email", validators=[DataRequired(), Email()])
    mobile_number = StringField("Mobile Number")

class ResetPasswordForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])

class OTPForm(FlaskForm):
    otp = StringField("OTP", validators=[DataRequired()])

class NewPasswordForm(FlaskForm):
    new_password = PasswordField("New Password", validators=[DataRequired()])
    confirm_new_password = PasswordField(
        "Confirm New Password", validators=[DataRequired(), EqualTo("new_password")]
    )

class ContactMessageForm(FlaskForm):
    name = StringField("Your Name", validators=[DataRequired()])
    email = StringField("Your Email", validators=[DataRequired(), Email()])
    message = TextAreaField("Your Message", validators=[DataRequired()])

    submit = SubmitField("Send Message")

class NewsletterSubscriptionForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    submit = SubmitField("Subscribe")
    
class AddProductForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(max=100)])
    description = TextAreaField("Description", validators=[DataRequired()])
    price = FloatField("Price", validators=[DataRequired(), NumberRange(min=0.01)])
    MRP_price = FloatField(
        "MRP price", validators=[DataRequired(), NumberRange(min=0.01)]
    )  # Add dummy price field
    quantity = IntegerField("Quantity", validators=[DataRequired(), NumberRange(min=1)])
    category = StringField("Category", validators=[DataRequired(), Length(max=50)])
    subcategory = StringField("Subcategory", validators=[DataRequired(), Length(max=50)])
    subtitle = StringField("Subtitle", validators=[Length(max=200)])
    carousel_display = BooleanField("Display in Carousel", default=True)
    gst_rate = SelectField(
    "GST Rate",
    choices=[("0", "0%"), ("5", "5%"), ("12", "12%"), ("18", "18%"), ("28", "28%")],
    coerce=float,
)
    images = StringField('Image Filenames (comma-separated)')
    video = StringField('Video Filename')
    
class CouponForm(FlaskForm):
    code = StringField('Code', validators=[DataRequired()])
    description = StringField('Description')
    discount_type = SelectField('Discount Type', choices=[('flat', 'Flat'), ('percent', 'Percentage')], validators=[DataRequired()])
    discount_value = FloatField('Discount Value', validators=[DataRequired()])
    minimum_order_amount = FloatField('Minimum Order Amount', default=0)
    max_discount_amount = FloatField('Max Discount (for %)', validators=[Optional()])  # Changed
    usage_limit = IntegerField('Usage Limit', validators=[Optional()])  # Changed
    applicable_products = SelectMultipleField('Applicable Products', coerce=int, validators=[Optional()])  # Changed
    valid_from = DateTimeField('Valid From', format='%Y-%m-%d %H:%M', validators=[Optional()])
    valid_until = DateTimeField('Valid Until', format='%Y-%m-%d %H:%M', validators=[Optional()])
    active = BooleanField('Active', default=True)
    def populate_obj(self, obj):
        # First populate all non-relationship fields
        for name, field in self._fields.items():
            if name != "applicable_products":  # Skip the relationship field
                field.populate_obj(obj, name)
        
        # Now handle the relationship separately
        product_ids = self.applicable_products.data
        obj.applicable_products = Product.query.filter(
            Product.id.in_(product_ids)
        ).all()