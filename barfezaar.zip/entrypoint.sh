#!/bin/sh

set -euo pipefail

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 🐍 Entrypoint script starting..."

DB_WAIT_TIMEOUT=60
ELAPSED=0

echo "[$(date '+%Y-%m-%d %H:%M:%S')] ⏳ Waiting for database to be ready..."

while ! flask db current > /dev/null 2>&1; do
  sleep 2
  ELAPSED=$((ELAPSED + 2))
  if [ "$ELAPSED" -ge "$DB_WAIT_TIMEOUT" ]; then
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ Database not ready after ${DB_WAIT_TIMEOUT} seconds. Exiting."
    exit 1
  fi
done

echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✅ Database is ready."

# Optional Redis check (uncomment if needed)
# echo "[$(date '+%Y-%m-%d %H:%M:%S')] ⏳ Checking Redis connectivity..."
# if ! redis-cli -h redis -a "${REDIS_PASSWORD}" ping | grep -q PONG; then
#   echo "[$(date '+%Y-%m-%d %H:%M:%S')] ❌ Redis not reachable. Exiting."
#   exit 1
# fi
# echo "[$(date '+%Y-%m-%d %H:%M:%S')] ✅ Redis is reachable."

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 📦 Running database migrations..."
flask db upgrade

echo "[$(date '+%Y-%m-%d %H:%M:%S')] 🚀 Starting application..."
exec "$@"
