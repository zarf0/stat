from datetime import timedelta
import secrets
import os
from dotenv import load_dotenv
from urllib.parse import quote_plus
# Load environment variables from .env file
load_dotenv()

class Config:
    # Security Configuration
    SECRET_KEY = os.getenv("SECRET_KEY")  # fallback only for dev  # 32 bytes = 256 bits
    SECRET_KEY = SECRET_KEY
    csrf_secret_key = secrets.token_hex(32)  # 32 bytes = 256 bits
    WTF_CSRF_SECRET_KEY = csrf_secret_key  # CSRF protection key
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 3600  # CSRF token validity (None for session)
    # Database Configuration
    DB_USER = quote_plus(os.getenv("DB_USER", "postgres"))
    DB_PASSWORD = quote_plus(os.getenv("DB_PASSWORD", "password"))
    DB_NAME = os.getenv("DB_NAME", "storedatabse")
    DB_HOST = os.getenv("DB_HOST", "localhost")
    SQLALCHEMY_DATABASE_URI = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    # Redis Configuration
    REDIS_PASSWORD = os.getenv("REDIS_PASSWORD")
    REDIS_URL = f"redis://default:{quote_plus(REDIS_PASSWORD)}@{REDIS_HOST}:{REDIS_PORT}/0"
    # Payment Gateway
    RAZORPAY_KEY_ID = os.getenv("RAZORPAY_KEY_ID")
    RAZORPAY_KEY_SECRET = os.getenv("RAZORPAY_KEY_SECRET")
    # GST Configuration
    BUSINESS_GSTIN = '27XXXXX1234X1X5'  
    BUSINESS_STATE_CODE = '01'  # Your business's state code
    UNION_TERRITORY_STATE_CODES = ["04", "31", "26", "35", "38"]
    # Email Configuration
    MAIL_SERVER = "smtp.gmail.com"
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USE_SSL = False
    MAIL_USERNAME = os.getenv("MAIL_USERNAME")
    MAIL_PASSWORD = os.getenv("MAIL_PASSWORD")
    MAIL_DEFAULT_SENDER = os.getenv("MAIL_DEFAULT_SENDER")
    CONTACT_EMAIL = os.getenv("CONTACT_EMAIL")
    MAIL_DEBUG = True
    EMAIL_TRACKING_ENABLED = True
    # Application Settings
    COMPANY_NAME = "BARF-E-ZAAR"
    COMPANY_ADDRESS = os.getenv("COMPANY_ADDRESS")
    ADMIN_EMAILS = os.getenv("ADMIN_EMAILS")
    PHONE_NUMBER = os.getenv("PHONE_NUMBER")
    WEBSITE_URL = "https://barf-e-zaar.com"
    PREFERRED_URL_SCHEME = "https"  # Force HTTPS URLs
    ORDERS_PER_PAGE = 5  # Number of orders per page for pagination
    
    # Session Security
    SESSION_COOKIE_SECURE = True  # Set secure cookie for HTTPS
    SESSION_COOKIE_HTTPONLY = True  # Prevent client-side JavaScript access to cookies
    SESSION_COOKIE_SAMESITE = "Lax"  # Set SameSite cookie attribute
    PERMANENT_SESSION_LIFETIME = timedelta(minutes=15)  # Session timeout in seconds (15 minutes)
    SESSION_REFRESH_EACH_REQUEST = True  # Regenerate session after each request
    SESSION_COOKIE_NAME = "secure_session"  # Set custom session cookie name
    SESSION_PERMANENT = True
    REMEMBER_COOKIE_SECURE = True
    # Rate Limiting
    RATELIMIT_STORAGE_URL = REDIS_URL
    RATELIMIT_HEADERS_ENABLED = True
    RATELIMIT_DEFAULT = "100 per minute"  # Rate limit configuration
    RATELIMIT_API = "30 per minute"
    RATELIMIT_STRATEGY = "fixed-window"    
    GITHUB_USER = "zarf0"
    REPO = "stat"
    BRANCH = "main"
    IMAGES_FOLDER = "images"  # Folder where images are stored in your repo
    VIDEOS_FOLDER = "videos"  # Folder where videos are stored in your repo
    # Content Security Policy
    CSP = {
        'default-src': "'self'",
        'script-src': [
            "'self'",
            "'unsafe-inline'",
            "https://cdn.jsdelivr.net",
            "https://code.jquery.com",
            "https://cdn.razorpay.com",
            "https://unpkg.com",
            "https://cdnjs.cloudflare.com",
            "https://cdn.quilljs.com"
        ],
        'style-src': [
            "'self'",
        'style-src': [
            "'self'",
            "'unsafe-inline'",
            "https://fonts.googleapis.com",
            "https://cdn.jsdelivr.net",
            "https://cdn.quilljs.com",
            "https://cdnjs.cloudflare.com",
            "https://unpkg.com"
        ],
        'img-src': [
            "'self'",
            "data:",
            "'unsafe-inline'",
            "https://cdn.jsdelivr.net",
            "https://api.razorpay.com",
            "https://img.freepik.com",
            "https://cdn.quilljs.com"
        ],
        'connect-src': [
            "'self'",
            "'unsafe-inline'",
            "https://api.razorpay.com",
            "https://cdn.razorpay.com",
            "https://cdn.quilljs.com",
            "https://cdn.jsdelivr.net",
        ],
        'font-src': [
            "'self'",
            "'unsafe-inline'",
            "https://fonts.gstatic.com",
            "https://cdn.quilljs.com",
            "https://cdn.jsdelivr.net",
            "https://cdnjs.cloudflare.com"
        ],
        'frame-src': [
            "'unsafe-inline'",
            "https://api.razorpay.com",
            "https://cdn.jsdelivr.net",
            "https://cdn.quilljs.com"
        ]
    }
    CSP_FORM_ACTION = ["'self'"]  # Allow form submissions from the same origin
    CSP_CONNECT_SRC = ["'self'"]  # Allow AJAX requests to the same origin
    PASSWORD_COMPLEXITY = {
        "min_length": 8,
        "uppercase": 1,
        "lowercase": 1,
        "digits": 1,
        "special": 1,
    }
    # File Uploads
    UPLOAD_FOLDER = "static/upload/product"
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10MB
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    ALLOWED_VIDEO_EXTENSIONS = {'mp4', 'avi', 'mov'}
    UPLOAD_EXTENSIONS = [".jpg", ".jpeg", ".png", ".gif"]

    # Monitoring
    PROMETHEUS_MULTIPROC_DIR = "/tmp/prometheus"
    LOG_FILE = "/var/log/flask/app.log"
def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS
    )

def allowed_file_video(filename):
    return '.' in filename and filename.rsplit(".", 1)[1].lower() in Config. ALLOWED_VIDEO_EXTENSIONS

class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///dev.db"
    SESSION_COOKIE_SECURE = False
    WTF_CSRF_ENABLED = False


class ProductionConfig(Config):
    DEBUG = False
    TESTING = False
    SESSION_COOKIE_DOMAIN = ".barf-e-zaar.com"
    PREFERRED_URL_SCHEME = "https"

    # Enhanced Security Headers
    SECURITY_HEADERS = {
        "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
        "X-Content-Type-Options": "nosniff",
        "X-Frame-Options": "DENY",
        "X-XSS-Protection": "1; mode=block",
        "Referrer-Policy": "strict-origin-when-cross-origin",
    }


