from sqlalchemy import  UniqueConstraint
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from extensions import db
from flask import url_for
import pytz 
import json
from Config import *
from flask import current_app

ist = pytz.timezone('Asia/Kolkata')
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    otp_secret = db.Column(db.String(16), nullable=False)
    orders = db.relationship("Order", back_populates="user")  # Updated
    billing_addresses = db.relationship("BillingAddress", backref="user", lazy=True)
    mobile_number = db.Column(db.String(20))
    cart_items = db.relationship("CartItem", backref="user", lazy=True)
    favorite_items = db.relationship("FavoriteItem", backref="user", lazy=True)

    __table_args__ = (
        UniqueConstraint("email", name="unique_email"),
        UniqueConstraint("mobile_number", name="unique_mobile_number"),
    )

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    user_name = db.Column(db.String(100))  # Added user_name 
    user_email = db.Column(db.String(120)) 
    billing_address = db.Column(db.String(300), nullable=False)  # Adjust size as needed
    products = db.Column(db.Text, nullable=False)  # Storing JSON string
    total_amount = db.Column(db.Float, nullable=False)
    currency = db.Column(db.String(3), nullable=False)
    
    order_id = db.Column(db.String(100))
    razorpay_payment_id = db.Column(db.String(100), nullable=False)
    razorpay_signature = db.Column(db.String(100))
    amount = db.Column(db.Float, nullable=False)
    payment_status = db.Column(db.String(20), nullable=False, default="Unpaid")
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ist))
    tracking_id = db.Column(db.String(100))
    delivery_status = db.Column(db.String(20), nullable=False, default="Pending")

    # Define relationships
    user = db.relationship("User", back_populates="orders")
    # Inside Order model
    coupon_code = db.Column(db.String(50), nullable=True)
    discount_applied = db.Column(db.Float, nullable=True, default=0.0)


    def set_billing_address(self, country, state, district, street, pincode):
        self.billing_address = f"{country}, {state}, {district}, {street}, {pincode}"

    def get_billing_address(self):
        return self.billing_address
    
    def set_products(self, product_list):
        """Store products with calculated total_price"""
        for product in product_list:
            if "total_price" not in product:
                product["total_price"] = product["quantity"] * product["unit_price"]
        self.products = json.dumps(product_list)

    def get_products(self):
        """Returns the products field as a list of product details."""
        return json.loads(self.products)
    
    
# Define Refund model
class Refund(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    razorpay_refund_id = db.Column(db.String(100), nullable=False)
    order_id = db.Column(db.Integer, db.ForeignKey("order.id"), nullable=False) 
    reason = db.Column(db.String(255), nullable=True)
    amount = db.Column(db.Float, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ist))
    refund_status = db.Column(db.String(20), nullable=False, default="Created")
     # Define relationship with Order model
    order = db.relationship('Order', backref='refunds')



class BillingAddress(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    name = db.Column(db.String(50),  nullable=False)
    mobile_number = db.Column(db.String(20))
    country = db.Column(db.String(100), nullable=False)
    district = db.Column(db.String(100), nullable=False)
    street = db.Column(db.String(100), nullable=False)
    pincode = db.Column(db.String(20), nullable=False)
    # State relationship
    state_id = db.Column(db.Integer, db.ForeignKey("state.id"), nullable=False)
    state = db.relationship("State", backref="addresses")
    

class State(db.Model):
    __tablename__ = "state"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    code = db.Column(db.String(2))  # 2-digit state code

# Define Product model
class Product(db.Model):
    __table_args__ = (
        db.CheckConstraint('quantity >= 0', name='non_negative_quantity'),
    )
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    MRP_price = db.Column(db.Float, nullable=True)  
    quantity = db.Column(db.Integer, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    subcategory = db.Column(db.String(50), nullable=False)
    gst_rate = db.Column(db.Float, nullable=False, default=0.0)  # ✅ GST rate in percentage
    subtitle = db.Column(db.String(200), nullable=True)
    carousel_display = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(ist))  
    feedback = db.relationship("Feedbackproduct", backref="product", lazy=True)  # Relationship with Feedback model
    images = db.relationship("ProductImage", backref="product", lazy=True, cascade="all, delete-orphan")
    video = db.Column(db.String(255), nullable=True)
    
    @property
    def video_url(self):
        if self.video:
            return f"https://cdn.jsdelivr.net/gh/{current_app.config['GITHUB_USER']}/{current_app.config['REPO']}@{current_app.config['BRANCH']}/videos/{self.video}"
        return None


# Place this before the Coupon model definition
coupon_product = db.Table(
    "coupon_product",
    db.Column("coupon_id", db.Integer, db.ForeignKey("coupon.id"), primary_key=True),
    db.Column("product_id", db.Integer, db.ForeignKey("product.id"), primary_key=True),
)


class Coupon(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.String(255))
    discount_type = db.Column(db.String(10), nullable=False)  # 'flat' or 'percent'
    discount_value = db.Column(db.Float, nullable=False)
    minimum_order_amount = db.Column(db.Float, default=0.0)
    max_discount_amount = db.Column(db.Float, nullable=True)
    usage_limit = db.Column(db.Integer, nullable=True)
    used_count = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)
    valid_from = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(ist))
    valid_until = db.Column(db.DateTime(timezone=True))
    # NEW: relationship to specific products
    applicable_products = db.relationship(
        "Product",
        secondary=coupon_product,
        backref=db.backref("coupons", lazy="dynamic"),
    )

    def is_valid(self, current_time, order_total):
        # Ensure timezone-aware comparisons
        current_time = current_time.replace(tzinfo=ist) if current_time.tzinfo is None else current_time
        valid_from = self.valid_from.replace(tzinfo=ist) if self.valid_from else None
        valid_until = self.valid_until.replace(tzinfo=ist) if self.valid_until else None
        
        if not self.active:
            return False
        if valid_from and current_time < valid_from:
            return False
        if valid_until and current_time > valid_until:
            return False
        if order_total < self.minimum_order_amount:
            return False
        if self.usage_limit and self.used_count >= self.usage_limit:
            return False
        return True

    def applies_to_product(self, product_id):
        """Check if coupon is applicable to a specific product (or to all if none set)."""
        if not self.applicable_products:
            return True  # No restriction → valid for all products
        return any(p.id == product_id for p in self.applicable_products)

class Feedbackproduct(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    star_rating = db.Column(db.Integer, nullable=False)  # Star rating from 1 to 5
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(ist)) 
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)


class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    quantity = db.Column(db.Integer, nullable=False, default=1)
    product = db.relationship("Product", backref="cart_items", lazy=True)


class FavoriteItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    product = db.relationship("Product", backref="favorite_items", lazy=True)


class ContactMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    message = db.Column(db.Text, nullable=False)


class Feedback(db.Model):
    __tablename__ = "feedback"
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)
    rating_value = db.Column(db.Integer, nullable=False)
    date_posted = db.Column(db.DateTime, default=lambda: datetime.now(ist))
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)  # Corrected the foreign key constraint
    date_submitted = db.Column(db.DateTime, default=lambda: datetime.now(ist), nullable=False)
    user = db.relationship("User", backref="feedback", lazy=True)


class NewsletterSubscription(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)


class ProductImage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("product.id"), nullable=False)
    filename = db.Column(db.String(100), nullable=False)
    
    @property
    def image_url(self):
        return f"https://cdn.jsdelivr.net/gh/{current_app.config['GITHUB_USER']}/{current_app.config['REPO']}@{current_app.config['BRANCH']}/images/{self.filename}"

    
    

