import re
from flask import Flask, render_template, request, redirect, url_for, flash, abort, jsonify, send_from_directory, session,  make_response
from flask_login import login_user, logout_user, login_required, current_user
from flask_wtf.csrf import CSRFProtect
from werkzeug.utils import secure_filename
import razorpay
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy import or_, desc, func
import os
from celery import Celery
import numpy as np
from flask_mail import Mail, Message
from datetime import datetime, date, time, timedelta
import time
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman
import requests
from flask_migrate import Migrate
from random import randint
from flask_socketio import SocketIO, emit
from werkzeug.security import generate_password_hash, check_password_hash
import pytz
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from flask_babel import Babel
from pyotp import TOTP
import logging
from prometheus_client import make_wsgi_app, Counter, Histogram
from werkzeug.middleware.dispatcher import DispatcherMiddleware
import hashlib
import hmac
import random
from flask_admin.contrib.sqla import ModelView
from flask_admin import expose, BaseView, Admin, AdminIndexView
import io
from redis import Redis
from Forms import*
from Models import*
from extensions import db, bcrypt, login_manager, mail
from Config import *
from utils import *
from sqlalchemy import inspect
app = Flask(__name__)
app.config.from_object(Config)
csrf = CSRFProtect(app)
db.init_app(app)
bcrypt.init_app(app)
login_manager.init_app(app)
socketio = SocketIO(app)
mail.init_app(app)
login_manager.init_app(app)
redis_client = Redis(host='redis', port=6379)
razorpay_client = razorpay.Client(auth=(app.config["RAZORPAY_KEY_ID"], app.config["RAZORPAY_KEY_SECRET"]))
celery = Celery(__name__, broker=Config.REDIS_URL)
# Redis client
redis_client = Redis(
    host=app.config["REDIS_HOST"],
    port=int(app.config["REDIS_PORT"]),
    password=app.config["REDIS_PASSWORD"],
    decode_responses=True,
)
redis_client = Redis.from_url(app.config["REDIS_URL"], decode_responses=True)
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    storage_uri=app.config["REDIS_URL"],
    default_limits=[app.config["RATELIMIT_DEFAULT"]],
)

def _parse_policy(policy):
    if isinstance(policy, dict):
        return " ".join(policy.keys())  # Return only the keys of the dictionary
    return " ".join(policy)
babel = Babel(app)
talisman = Talisman(
    app,
    force_https=True,
    strict_transport_security=True,
    strict_transport_security_max_age=31536000,
    content_security_policy=app.config['CSP'],
    session_cookie_secure=True,
    referrer_policy='strict-origin-when-cross-origin'
)
migrate = Migrate(app, db)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app.logger.setLevel(logging.INFO)
# Add Prometheus metrics
REQUEST_COUNTER = Counter(
    'flask_http_request_total',
    'Total HTTP Requests',
    ['method', 'endpoint', 'http_status']
)

REQUEST_LATENCY = Histogram(
    'flask_http_request_duration_seconds',
    'HTTP Request Latency',
    ['method', 'endpoint']
)

# Add after app initialization
app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {
    '/metrics': make_wsgi_app()
})

@app.before_request
def set_start_time():
    request.start_time = time.time()  # Initialize the attribute

# Example metric usage in a route
@app.before_request
def before_request():
    request.start_time = time.time()

@app.after_request
def after_request(response):
    # Check if start_time exists
    start_time = getattr(request, 'start_time', None)

    if start_time is not None:
        latency = time.time() - start_time
        REQUEST_LATENCY.labels(request.method, request.path).observe(latency)
    else:
        app.logger.warning("Request has no start_time attribute")

    REQUEST_COUNTER.labels(request.method, request.path, response.status_code).inc()
    return response
class AdminIndex(AdminIndexView):
    @expose('/')
    def index(self):
        if not current_user.is_admin:
            abort(403)
        return super(AdminIndex, self).index()

class AdminModelView(ModelView):
    def is_accessible(self):
        return current_user.is_admin

    def get_query(self):
        if not current_user.is_admin:
            return self.session.query(self.model)
        else:
            # Return only the instances that the user has permission to access
            return self.session.query(self.model).filter_by(username=current_user.username)



class AdminLogoutView(BaseView):
    @expose('/')
    def index(self):
        logout_user()
        return redirect(url_for('admin.index'))
admin = Admin(app, name="Zafranoosh Admin Panel", template_mode="bootstrap3", index_view=AdminIndex())

admin.add_view(ModelView(User, db.session))
admin.add_view(ModelView(Order, db.session))
admin.add_view(ModelView(Refund, db.session))
admin.add_view(ModelView(State, db.session))
admin.add_view(ModelView(BillingAddress, db.session))
admin.add_view(ModelView(Product, db.session))
admin.add_view(ModelView(ProductImage, db.session))
admin.add_view(ModelView(CartItem, db.session))
admin.add_view(ModelView(FavoriteItem, db.session))
admin.add_view(ModelView(Coupon, db.session))
admin.add_view(ModelView(ContactMessage, db.session))
admin.add_view(ModelView(Feedback, db.session))
admin.add_view(ModelView(Feedbackproduct, db.session))
admin.add_view(ModelView(NewsletterSubscription, db.session))

#@app.before_request
#def before_request():
#    if request.endpoint != 'static':
#        if not oidc.user_loggedin:
#            return oidc.redirect_to_auth_server(request.url)
        
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


def get_recently_viewed_products():
    recently_viewed_ids = request.cookies.get("recently_viewed")
    if recently_viewed_ids:
        ids = [int(id) for id in recently_viewed_ids.split(",")]
        return Product.query.filter(Product.id.in_(ids)).all()
    return []


from symspellpy import SymSpell, Verbosity

# Initialize SymSpell
sym_spell = SymSpell(max_dictionary_edit_distance=2, prefix_length=7)

def build_spell_checker():
    # Check if the Product table exists
    inspector = inspect(db.engine)
    if not inspector.has_table('product'):
        print("Product table does not exist. Skipping spell checker build.")
        return
    # Extract all product terms from database
    products = Product.query.all()
    corpus = []
    
    for product in products:
        corpus.append(product.name)
        corpus.append(product.description)
        corpus.append(product.category)
        corpus.append(product.subcategory)

    # Create frequency dictionary
    word_freq = {}
    for text in corpus:
        words = re.sub(r'[^\w\s]', '', text).lower().split()
        for word in words:
            word_freq[word] = word_freq.get(word, 0) + 1

    # Add to SymSpell dictionary
    for word, freq in word_freq.items():
        sym_spell.create_dictionary_entry(word, freq)

# Build during app initialization
with app.app_context():
    build_spell_checker()
    
@app.route("/search_suggestions")
def search_suggestions():
    query = request.args.get("q", "").strip().lower()
    results = []

    if not query:
        return jsonify([])

    try:
        # Check original query terms first
        original_terms = query.split()
        original_conditions = []
        for term in original_terms:
            term_pattern = f"%{term}%"
            original_conditions.append(Product.name.ilike(term_pattern))
            original_conditions.append(Product.description.ilike(term_pattern))

        # Query with original terms
        original_products = []
        if original_conditions:
            original_products = (
                Product.query.filter(db.or_(*original_conditions)).limit(5).all()
            )

        if original_products:
            for product in original_products:
                image_url = (
                    product.images[0].image_url
                    if product.images
                    else url_for("static", filename="images/placeholder.jpg")
                )
                results.append(
                    {
                        "type": "product",
                        "id": product.id,
                        "name": product.name,
                        "image": image_url,
                        "url": url_for("product", product_id=product.id),
                    }
                )
            return jsonify(results)

        # Proceed to correct if no original products found
        corrections = []
        terms = query.split()
        for word in terms:
            suggestions = sym_spell.lookup(word, Verbosity.TOP, max_edit_distance=2)
            if suggestions:
                corrections.append(suggestions[0].term)
            else:
                corrections.append(word)

        corrected_query = " ".join(corrections)

        # Add correction suggestion if different
        if corrected_query != query:
            results.append(
                {
                    "type": "correction",
                    "query": corrected_query,
                    "text": f"Did you mean: {corrected_query}?",
                }
            )

        # Build search conditions for corrected query
        search_terms = corrected_query.split()
        conditions = []
        for term in search_terms:
            term_pattern = f"%{term}%"
            conditions.append(Product.name.ilike(term_pattern))
            conditions.append(Product.description.ilike(term_pattern))

        # Get matching products
        if conditions:
            products = Product.query.filter(db.or_(*conditions)).limit(5).all()

            for product in products:
                image_url = (
                    product.images[0].image_url
                    if product.images
                    else url_for("static", filename="images/placeholder.jpg")
                )
                results.append(
                    {
                        "type": "product",
                        "id": product.id,
                        "name": product.name,
                        "image": image_url,
                        "url": url_for("product", product_id=product.id),
                    }
                )

        return jsonify(results)

    except Exception as e:
        logging.error(f"Search suggestions error: {str(e)}")
        return jsonify([])
@app.route("/search")
def search():
    original_query = request.args.get("search", "").strip()
    search_term = original_query.lower()
    page = request.args.get("page", 1, type=int)
    per_page = 10  # Items per page

    # Spell correction logic
    corrections = []
    for word in search_term.split():
        suggestions = sym_spell.lookup(word, Verbosity.TOP, max_edit_distance=2)
        corrections.append(suggestions[0].term if suggestions else word)

    corrected_query = " ".join(corrections)
    final_query = corrected_query if corrected_query != search_term else search_term

    # Search logic
    terms = final_query.split()
    conditions = [
        db.or_(Product.name.ilike(f"%{term}%"), Product.description.ilike(f"%{term}%"))
        for term in terms
    ]

    products = Product.query.filter(db.and_(*conditions)).paginate(
        page=page, per_page=per_page, error_out=False
    )

    return render_template(
        "search_results.html",
        products=products,
        original_query=original_query,
        corrected_query=corrected_query,
    )

@app.route('/health')
def health_check():
    return jsonify(status="healthy"), 200

POSTS_PER_PAGE = 5

@app.route("/", methods=['GET', 'POST'])
def index():
    newsletter_form = NewsletterSubscriptionForm()
    # Handle newsletter form submission
    if newsletter_form.validate_on_submit():
        email = newsletter_form.email.data
        existing_sub = NewsletterSubscription.query.filter_by(email=email).first()
        
        if existing_sub:
            flash('You are already subscribed!', 'info')
        else:
            new_sub = NewsletterSubscription(email=email)
            db.session.add(new_sub)
            db.session.commit()
            
            send_confirmation_email(email)
            flash('Thank you for subscribing to our newsletter!', 'success')
        return redirect(url_for('index'))  # Prevent form resubmission

    # Base product query with filters
    products_query = Product.query
    products = products_query.all()

    # Add short descriptions
    for product in products:
        product.short_description = (
            (product.description[:50] + "...")
            if len(product.description) > 50
            else product.description
        )

    # Get all categories for navigation
    all_categories = [c[0] for c in db.session.query(Product.category).distinct().all()]

    # Best selling and carousel products
    best_selling = Product.query.filter_by(carousel_display=True).limit(3).all()
    carousel_products = Product.query.filter_by(carousel_display=True).limit(3).all()

    # Recently viewed and cart data
    recently_viewed_products = get_recently_viewed_products()
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)

    # Top coupons
    top_coupons = (
        Coupon.query.filter(
            Coupon.active == True,
            Coupon.valid_from <= datetime.now(ist),
            Coupon.valid_until >= datetime.now(ist),
        )
        .order_by(Coupon.discount_value.desc())
        .limit(3)
        .all()
    )

    # Discounted categories with max discount calculation
    discounted_categories = []

    # Get categories with their maximum discounts
    category_discounts = (
        db.session.query(
            Product.category,
            func.max(
                ((Product.MRP_price - Product.price) / Product.MRP_price * 100)
            ).label("max_discount"),
        )
        .filter(Product.MRP_price.isnot(None), Product.MRP_price > Product.price)
        .group_by(Product.category)
        .all()
    )

    for category, discount in category_discounts:
        # Get product with highest discount in category
        representative_product = (
            Product.query.filter(
                Product.category == category, Product.MRP_price > Product.price
            )
            .order_by(
                ((Product.MRP_price - Product.price) / Product.MRP_price * 100).desc()
            )
            .first()
        )

        if representative_product:
            # Get image URL with fallback
            if representative_product.images:
                image_url = representative_product.images[0].image_url
            else:
                image_url = url_for("static", filename="images/placeholder.jpg")

            discounted_categories.append(
                {
                    "name": category,
                    "max_discount": round(discount),
                    "image_url": image_url,
                    "url": url_for("products_by_category", category=category),
                }
            )

    # Sort by discount and select top 2
    discounted_categories.sort(key=lambda x: x["max_discount"], reverse=True)
    top_discounted = discounted_categories[:2]

    current_time = datetime.now(ist)

    # Query products with their valid coupons
    products_with_coupons = (
        db.session.query(Product, Coupon)
        .join(coupon_product, Product.id == coupon_product.c.product_id)
        .join(Coupon, Coupon.id == coupon_product.c.coupon_id)
        .filter(
            Coupon.active == True,
            Coupon.valid_from <= current_time,
            Coupon.valid_until >= current_time,
            (Coupon.usage_limit == None) | (Coupon.usage_limit > Coupon.used_count),
        )
        .all()
    )

    product_coupon_map = {}
    for product, coupon in products_with_coupons:
        if product.id not in product_coupon_map:
            product_coupon_map[product.id] = (product, coupon)
        else:
            # Keep the coupon with higher discount
            current_coupon = product_coupon_map[product.id][1]
            new_discount = (
                coupon.discount_value
                if coupon.discount_type == "flat"
                else product.price * (coupon.discount_value / 100)
            )
            current_discount = (
                current_coupon.discount_value
                if current_coupon.discount_type == "flat"
                else product.price * (current_coupon.discount_value / 100)
            )
            if new_discount > current_discount:
                product_coupon_map[product.id] = (product, coupon)

    # Initialize deal variables
    max_discount = 0
    deal_product = None
    deal_coupon = None
    original_price = None
    discounted_price = None

    if product_coupon_map:
        # Find the product-coupon combination with highest effective discount
        for product, coupon in product_coupon_map.values():
            # Calculate effective discount
            if coupon.discount_type == "flat":
                current_discount = coupon.discount_value
            else:
                current_discount = product.price * (coupon.discount_value / 100)
                if coupon.max_discount_amount:
                    current_discount = min(current_discount, coupon.max_discount_amount)

            # Track maximum discount
            if current_discount > max_discount:
                max_discount = current_discount
                deal_product = product
                deal_coupon = coupon

        # Calculate prices for the best deal
        if deal_product and deal_coupon:
            original_price = (deal_product.MRP_price if deal_product.MRP_price else deal_product.price)
            current_price = deal_product.price
            discounted_price = current_price - max_discount
    clothing_subcategories = [sub[0]for sub in db.session.query(Product.subcategory).filter_by(category="Clothing").distinct().all()]
    return render_template("index.html",products=products,categories=all_categories,discounted_categories=top_discounted,newsletter_form=newsletter_form,
        recently_viewed_products=recently_viewed_products,cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,
        best_selling=best_selling,carousel_products=carousel_products,top_coupons=top_coupons,deal_product=deal_product,
        deal_coupon=deal_coupon,original_price=original_price,discounted_price=discounted_price,clothing_subcategories=clothing_subcategories,)

@app.route("/add_product", methods=["GET", "POST"])
@login_required
def add_product():
    if not current_user.is_admin:
        abort(403)  
    form = AddProductForm(request.form)

    if form.validate_on_submit():

        # Create a new Product instance
        product = Product(
            name=form.name.data,
            description=form.description.data,
            price=form.price.data,
            MRP_price=form.MRP_price.data,
            quantity=form.quantity.data,
            category=form.category.data,
            subcategory=form.subcategory.data,
            gst_rate=form.gst_rate.data, 
            subtitle=form.subtitle.data,
            carousel_display=form.carousel_display.data,
            created_at=datetime.utcnow(),
            video = form.video.data.strip() if form.video.data else None
        )
        

        db.session.add(product)
        db.session.commit()

        
        # Handle image filenames
        image_filenames = [f.strip() for f in form.images.data.split(',') if f.strip()]
        for filename in image_filenames:
            product_image = ProductImage(product_id=product.id, filename=filename)
            db.session.add(product_image)
        db.session.commit()

        # Handle video
        video = request.files.get("video")
        if video and allowed_file_video(video.filename):
            filename = secure_filename(video.filename)
            video_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            video.save(video_path)
            product.video = filename
            db.session.commit()  # Commit changes after saving the video
        else:
            flash('Invalid video format. Only MP4, AVI, and MOV are allowed.')

        db.session.commit()

        flash("Product added successfully", "success")
        return redirect(url_for("product_list"))

    # Debug: Check form validation errors
    print("Form validation errors:", form.errors)

    flash("Failed to add product", "error")
    return render_template("add_product.html", form=form)


@app.route("/edit_product/<int:product_id>", methods=["GET", "POST"])
@login_required
def edit_product(product_id):
    if not current_user.is_admin:
        abort(403)  # Forbidden

    product = Product.query.get_or_404(product_id)
    form = AddProductForm(request.form, obj=product)

    if form.validate_on_submit():
        # Update fields
        product.name = form.name.data
        product.description = form.description.data
        product.price = form.price.data
        product.MRP_price = form.MRP_price.data
        product.gst_rate = form.gst_rate.data
        product.quantity = form.quantity.data
        product.category = form.category.data
        product.subcategory = form.subcategory.data
        product.subtitle = form.subtitle.data
        product.carousel_display = form.carousel_display.data
        product.video = form.video.data.strip() if form.video.data else None

        # --- Handle Image Update ---
        images = request.files.getlist("images")
        new_filenames = [f.strip() for f in form.images.data.split(",") if f.strip()]
        if new_filenames:
            # Delete old images
            for img in product.images:
                db.session.delete(img)
            # Add new images
            for filename in new_filenames:
                product_image = ProductImage(product_id=product.id, filename=filename)
                db.session.add(product_image)

        # --- Handle Video ---
        video = request.files.get("video")
        if video and video.filename != "" and allowed_file(video.filename):
            filename = secure_filename(video.filename)
            video_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            video.save(video_path)
            product.video = filename

        db.session.commit()
        flash("Product updated successfully", "success")
        return redirect(url_for("product_list"))

    return render_template("edit_product.html", form=form, product=product)


@app.route("/delete_product/<int:product_id>", methods=["GET", "POST"])
@login_required
def delete_product(product_id):
    if not current_user.is_admin:
        abort(403)  # Forbidden
    product = Product.query.get_or_404(product_id)

    # Delete cart items associated with the product
    cart_items = CartItem.query.filter_by(product_id=product.id).all()
    for item in cart_items:
        db.session.delete(item)

    # Delete feedbacks associated with the product
    feedbacks = Feedbackproduct.query.filter_by(product_id=product.id).all()
    for feedback in feedbacks:
        db.session.delete(feedback)

    # Now delete the product
    db.session.delete(product)
    db.session.commit()
    cart_item_count = len(cart_items)  
    flash("Product deleted successfully", "success")
    return redirect(url_for("product_list"), cart_item_count=len(cart_items),)
@app.route("/subcategory/<subcategory_name>")
def view_subcategory(subcategory_name):
    print("Subcategory received:", subcategory_name)
    products = Product.query.filter_by(subcategory=subcategory_name).all()
    print("Found products:", products)
    return render_template(
        "subcategory.html", products=products, subcategory=subcategory_name
    )
import bleach
@app.route("/products")
def product_list():
    per_page = request.args.get('show', 9, type=int)  
    sort_by = request.args.get('sort_by', 'name')  
    view_mode = request.args.get("view_mode", "grid")  
    selected_category = request.args.get('category', None)
    selected_price_range = request.args.get('price', None)  

    # Start with a base query
    products_query = Product.query

    # Apply category filter
    if selected_category:
        products_query = products_query.filter(Product.category == selected_category)

    # Apply price filter
    if selected_price_range and "-" in selected_price_range:
        try:
            min_price, max_price = map(int, selected_price_range.split("-"))
            products_query = products_query.filter(
            Product.price >= min_price, Product.price <= max_price)
        except ValueError:
            pass  # Ignore invalid input and return all products
    # Apply sorting
    if sort_by == "name":
        products_query = products_query.order_by(Product.name)
    elif sort_by == "price_asc":
        products_query = products_query.order_by(Product.price)
    elif sort_by == "price_desc":
        products_query = products_query.order_by(desc(Product.price))

    # Apply pagination
    products = products_query.limit(per_page).all()
    # Get all feedback for the product
    
    # Fetch all unique categories
    categories = db.session.query(Product.category).distinct().all()
    categories = [c[0] for c in categories]  

    # Fetch recent products along with feedbacks
    recent_products = (db.session.query(Product).outerjoin(Feedbackproduct).order_by(Product.created_at.desc()).limit(3).all())
    # Fetch feedbacks for all products
    feedbacks_dict = {product.id: Feedbackproduct.query.filter_by(product_id=product.id).all()for product in recent_products}
   
    # Generate price ranges
    prices = [product.price for product in Product.query.all()]
    price_ranges = []
    if prices:
        percentiles = np.percentile(prices, [0, 25, 50, 75, 100])
        for i in range(len(percentiles) - 1):
            price_ranges.append({
                "range": f"₹{int(percentiles[i])} - ₹{int(percentiles[i+1])}",
                "min": int(percentiles[i]),
                "max": int(percentiles[i+1]),
                "count": sum(p >= percentiles[i] and p < percentiles[i+1] for p in prices)
            })
    # Fetch cart items for the logged-in user (if authenticated)
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template(
        "product_list.html", 
        products=products, 
        categories=categories, 
        recent_products=recent_products, 
        price_ranges=price_ranges,
        per_page=per_page, 
        sort_by=sort_by, 
        view_mode=view_mode, feedbacks_dict = feedbacks_dict, cart_items=cart_items,
        cart_item_count=cart_item_count,
        total_price=total_price,
    )


@app.route("/product/<int:product_id>")
def product(product_id):
    product = Product.query.get_or_404(product_id)
    products = Product.query.filter(Product.id != product_id).all()  # Exclude current product

    # Initialize variables for authenticated users
    can_leave_feedback = False
    purchased_product_ids = []
    cart_items = []
    cart_item_count = 0
    total_price = 0

    # Only check purchases if user is logged in
    if current_user.is_authenticated:
        # Check if the user has purchased this product
        user_orders = Order.query.filter_by(user_id=current_user.id).all()
        for order in user_orders:
            order_products = json.loads(order.products)
            purchased_product_ids.extend([p['product_id'] for p in order_products])

        can_leave_feedback = product_id in purchased_product_ids

        # Get cart items for logged-in users
        cart_items = current_user.cart_items
        cart_item_count = len(cart_items)
        total_price = sum(item.product.price * item.quantity for item in cart_items)

    # Get all feedback for the product
    feedbacks = Feedbackproduct.query.filter_by(product_id=product.id).all()

    # Update recently viewed products
    recently_viewed_ids = request.cookies.get('recently_viewed', '')
    recently_viewed = recently_viewed_ids.split(',') if recently_viewed_ids else []

    if str(product_id) not in recently_viewed:
        recently_viewed.append(str(product_id))
        if len(recently_viewed) > 10:  # Limit to 10 recently viewed products
            recently_viewed.pop(0)
    
    # Fetch unique categories from the database
    categories = db.session.query(Product.category).distinct().all()
    categories = [category[0] for category in categories]
    
    response = make_response(render_template(
        "product.html",
        product=product,
        products=products,
        can_leave_feedback=can_leave_feedback,
        feedbacks=feedbacks,
        cart_items=cart_items,
        cart_item_count=cart_item_count,
        total_price=total_price,
        categories=categories 
    ))
    response.set_cookie('recently_viewed', ','.join(recently_viewed))

    return response

@app.route("/products/<category>")
def products_by_category(category):
    products = Product.query.filter_by(category=category).all()
     # Fetch unique categories from the database
    categories = db.session.query(Product.category).distinct().all()
    categories = [category[0] for category in categories]
    # Fetch cart items for the logged-in user (if authenticated)
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template("products_by_category.html", products=products, categories=categories, cart_items=cart_items, cart_item_count=cart_item_count, total_price=total_price,)

@app.route("/submit_feedback/<int:product_id>", methods = ["GET", "POST"])
@login_required
def submit_feedback(product_id):
    product = Product.query.get_or_404(product_id)

    # Check if the user has purchased the product
    user_orders = Order.query.filter_by(user_id=current_user.id).all()
    purchased_product_ids = []
    for order in user_orders:
        order_products = json.loads(order.products)
        for product_data in order_products:
            purchased_product_ids.append(product_data["product_id"])

    if product_id not in purchased_product_ids:
        flash("You need to purchase this product to leave feedback.", "error")
        return redirect(url_for("product", product_id=product_id))

    # Get feedback form data
    title = request.form.get("title")
    description = request.form.get("description")
    star_rating = request.form.get("star_rating")

    # Create new feedback
    new_feedback = Feedbackproduct(
        title=title,
        description=description,
        star_rating=int(star_rating),
        product_id=product.id,
        created_at=datetime.now(ist),
    )
    db.session.add(new_feedback)
    db.session.commit()

    flash("Thank you for your feedback!", "success")
    return redirect(url_for("product", product_id=product_id))

# Coupon Admin Routes
@app.route("/admin/coupons")
@login_required
def admin_coupons():
    if not current_user.is_admin:
        abort(403)
    coupons = Coupon.query.all()
    return render_template("admin/coupons.html", coupons=coupons)


@app.route("/admin/coupon/add", methods=["GET", "POST"])
@login_required
def add_coupon():
    if not current_user.is_admin:
        abort(403)
    form = CouponForm()
    form.applicable_products.choices = [(p.id, p.name) for p in Product.query.all()]

    if form.validate_on_submit():
        coupon = Coupon(
            code=form.code.data.upper(),
            description=form.description.data,
            discount_type=form.discount_type.data,
            discount_value=form.discount_value.data,
            minimum_order_amount=form.minimum_order_amount.data,
            max_discount_amount=form.max_discount_amount.data,
            usage_limit=form.usage_limit.data,
            valid_from=form.valid_from.data,
            valid_until=form.valid_until.data,
            active=form.active.data,
        )

        # Add selected products
        product_ids = form.applicable_products.data
        coupon.applicable_products = Product.query.filter(
            Product.id.in_(product_ids)
        ).all()

        db.session.add(coupon)
        db.session.commit()
        flash("Coupon created successfully", "success")
        return redirect(url_for("admin_coupons"))

    return render_template("admin/add_coupon.html", form=form)


@app.route("/admin/coupon/edit/<int:coupon_id>", methods=["GET", "POST"])
def edit_coupon(coupon_id):
    coupon = Coupon.query.get_or_404(coupon_id)
    form = CouponForm(obj=coupon)
    form.applicable_products.choices = [(p.id, p.name) for p in Product.query.all()]

    if form.validate_on_submit():
        form.populate_obj(coupon)  # Uses the custom method
        db.session.commit()
        flash("Coupon updated successfully", "success")
        return redirect(url_for("admin_coupons"))

    form.applicable_products.data = [p.id for p in coupon.applicable_products]
    return render_template("admin/edit_coupon.html", form=form, coupon=coupon)


@app.route("/admin/coupon/delete/<int:coupon_id>", methods=["POST"])
@login_required
def delete_coupon(coupon_id):
    if not current_user.is_admin:
        abort(403)
    coupon = Coupon.query.get_or_404(coupon_id)
    db.session.delete(coupon)
    db.session.commit()
    flash("Coupon deleted successfully", "success")
    return redirect(url_for("admin_coupons"))


@app.route("/apply_coupon", methods=["POST"])
@login_required
def apply_coupon():
    data = request.get_json()
    coupon_code = data.get("coupon_code", "").strip().upper()

    cart_items = current_user.cart_items
    if not cart_items:
        return jsonify({"success": False, "error": "Cart is empty"})

    subtotal = sum(item.product.price * item.quantity for item in cart_items)
    coupon = Coupon.query.filter_by(code=coupon_code).first()

    if not coupon:
        return jsonify({"success": False, "error": "Invalid coupon code"})

    # Ensure timezone-aware comparisons
    current_time = datetime.now(ist)
    valid_from = coupon.valid_from.astimezone(ist) if coupon.valid_from else None
    valid_until = coupon.valid_until.astimezone(ist) if coupon.valid_until else None

    validation_errors = {
        "inactive": not coupon.active,
        "expired": valid_until and current_time > valid_until,
        "future": valid_from and current_time < valid_from,
        "min_amount": subtotal < coupon.minimum_order_amount,
        "usage_limit": coupon.usage_limit and coupon.used_count >= coupon.usage_limit,
        "products": bool(coupon.applicable_products)
        and not {item.product_id for item in cart_items}.issubset(
            {p.id for p in coupon.applicable_products}
        ),
    }

    if any(validation_errors.values()):
        error_messages = {
            "inactive": "Coupon is inactive",
            "expired": "Coupon has expired",
            "future": "Coupon is not yet valid",
            "min_amount": f"Minimum order amount ₹{coupon.minimum_order_amount} required",
            "usage_limit": "Coupon usage limit reached",
            "products": "Coupon not applicable to cart items",
        }
        error = next(v for k, v in error_messages.items() if validation_errors[k])
        return jsonify({"success": False, "error": error})

    # Calculate discount
    if coupon.discount_type == "flat":
        discount = coupon.discount_value
    else:
        discount = subtotal * (coupon.discount_value / 100)
        if coupon.max_discount_amount:
            discount = min(discount, coupon.max_discount_amount)

    discount = min(discount, subtotal)
    session["applied_coupon"] = {
        "code": coupon.code,
        "discount": discount,
        "coupon_id": coupon.id,
    }

    return jsonify(
        {
            "success": True,
            "discount": discount,
            "new_total": subtotal - discount,
            "coupon_code": coupon.code,
        }
    )


@app.route("/remove_coupon", methods=["POST"])
@login_required
def remove_coupon():
    session.pop("applied_coupon", None)
    return jsonify({"success": True})

@app.route('/get_applicable_coupons')
@login_required
def get_applicable_coupons():
    try:
        cart_items = current_user.cart_items
        cart_product_ids = {item.product_id for item in cart_items}
        cart_total = sum(item.product.price * item.quantity for item in cart_items)
        current_time = datetime.now(ist)

        all_coupons = Coupon.query.filter(
            Coupon.active == True,
            Coupon.valid_from <= current_time,
            (Coupon.valid_until == None) | (Coupon.valid_until >= current_time)
        ).all()

        result = []
        for coupon in all_coupons:
            coupon_data = {
                'code': coupon.code,
                'description': coupon.description,
                'discount_type': coupon.discount_type,
                'discount_value': coupon.discount_value,
                'minimum_order_amount': coupon.minimum_order_amount,
                'max_discount_amount': coupon.max_discount_amount,
                'applicable': True,
                'suggestion_message': None,
                'products_needed': []
            }

            # Check minimum order amount
            amount_needed = max(coupon.minimum_order_amount - cart_total, 0)
            
            # Check product requirements
            required_products = [p for p in coupon.applicable_products 
                               if p.id not in cart_product_ids]
            
            # Build suggestions
            suggestions = []
            if amount_needed > 0:
                suggestions.append(f"Add ₹{amount_needed:.2f} more to your cart")
                
            if required_products:
                product_names = [p.name for p in required_products[:2]]  # Show max 2 products
                suggestions.append(f"Add {', '.join(product_names)}")
                coupon_data['products_needed'] = [{
                    'id': p.id,
                    'name': p.name,
                    'category': p.category
                } for p in required_products]

            # Check if coupon is applicable
            if coupon.usage_limit and coupon.used_count >= coupon.usage_limit:
                coupon_data['applicable'] = False
                coupon_data['suggestion_message'] = "Coupon usage limit reached"
            elif len(suggestions) > 0:
                coupon_data['applicable'] = False
                coupon_data['suggestion_message'] = "To use this coupon: " + " or ".join(suggestions)

            result.append(coupon_data)

        return jsonify(result)

    except Exception as e:
        logger.error(f"Error getting coupons: {e}")
        return jsonify([])
    
@app.route("/payment/cart", methods=["POST"])
@limiter.limit("10 per minute", error_message="Too many payment requests. Please wait.")
@login_required
def payment_cart():
    try:
        # Stock validation before payment processing
        cart_items = current_user.cart_items
        errors = []
        
        # Check stock availability and collect errors
        for item in cart_items:
            product = Product.query.get(item.product_id)
            if not product:
                errors.append(f"Product {item.product_id} no longer exists")
                continue
                
            if item.quantity > product.quantity:
                available = product.quantity
                requested = item.quantity
                errors.append(
                    f"{product.name}: Only {available} available (you requested {requested})"
                )
        
        if errors:
            for error in errors:
                flash(error, "danger")
            return redirect(url_for("cart"))
        # Retrieve billing address ID from form
        billing_address_id = request.form.get("billing_address_id")
        address_line_1 = request.form.get("address_line_1")
        city = request.form.get("city")
        state = request.form.get("state")
        zip_code = request.form.get("zip_code")
        
        if billing_address_id == "new" and address_line_1 and city and state and zip_code:
            # Create new billing address
            new_address = BillingAddress(
                user_id=current_user.id,
                address_line_1=address_line_1,
                city=city,
                state=state,
                zip_code=zip_code
            )
            db.session.add(new_address)
            db.session.commit()
            billing_address_id = new_address.id
        elif not billing_address_id:
            flash("Please select or provide a billing address.", "danger")
            return redirect(url_for("payment_checkout"))

        # Save selected billing address ID to session
        session['billing_address_id'] = billing_address_id
         # Retrieve the billing address details
        billing_address = BillingAddress.query.get(billing_address_id)
        if not billing_address:
            flash("Billing address not found.", "danger")
            return redirect(url_for("payment_checkout"))

        cart_items = current_user.cart_items
        subtotal = sum(item.product.price * item.quantity for item in cart_items)
        final_amount = subtotal

        # Validate and apply coupon with proper timezone handling
        applied_coupon = session.get("applied_coupon")
        if applied_coupon:
            coupon = Coupon.query.filter_by(code=applied_coupon["code"]).first()
            if coupon:
                # Convert coupon times to aware datetimes
                current_time = datetime.now(ist)
                valid_from = coupon.valid_from.replace(tzinfo=ist) if coupon.valid_from else None
                valid_until = coupon.valid_until.replace(tzinfo=ist) if coupon.valid_until else None
                
                # Validate coupon with proper time comparisons
                valid = True
                if not coupon.active:
                    valid = False
                elif valid_from and current_time < valid_from:
                    valid = False
                elif valid_until and current_time > valid_until:
                    valid = False
                elif subtotal < coupon.minimum_order_amount:
                    valid = False
                
                if valid:
                    final_amount -= applied_coupon["discount"]
                else:
                    session.pop("applied_coupon", None)
                    flash("Coupon is no longer valid", "warning")

        
        razorpay_order = razorpay_client.order.create({
            "amount": int(final_amount * 100),
            "currency": "INR",
            "payment_capture": "1",
        })
        
        return render_template(
            "payment.html",
            cart_items=cart_items,
            final_total=final_amount,
            order_id=razorpay_order["id"],
            billing_address = billing_address,
        )
    except Exception as e:
        logger.error(f"Payment error: {e}")
        flash("Payment processing error", "danger")
        return redirect(url_for("cart"))

@app.route('/payment/checkout', methods=['GET'])
@login_required
def payment_checkout():
    try:
        # Retrieve existing billing addresses
        states = State.query.all()  # Get all states from database
        billing_addresses = current_user.billing_addresses
        return render_template('checkout.html', billing_addresses=billing_addresses, states=states)
    except Exception as e:
        logger.error(f"Error in payment_checkout: {e}")
        return render_template('error.html', error=str(e)), 400

@app.route("/payment/success")
@login_required
def payment_success():
    try:
        # Retrieve payment data
        payment_id = request.args.get("payment_id")
        order_id = request.args.get("order_id")
        signature = request.args.get("signature")


        if not all([payment_id, order_id, signature]):
            flash("Invalid payment confirmation parameters", "danger")
            return redirect(url_for("cart"))
    
        # Verify the payment signature
        params_dict = {
            "razorpay_order_id": order_id,
            "razorpay_payment_id": payment_id,
            "razorpay_signature": signature,
        }

        try:
            razorpay_client.utility.verify_payment_signature(params_dict)
        except razorpay.errors.SignatureVerificationError as e:
            logger.error(f"Payment signature verification failed: {e}")
            return render_template("error.html", error="Invalid payment signature"), 400

        # Start atomic transaction
        with db.session.begin_nested():
            # Reload cart items with lock
            cart_items = CartItem.query.filter_by(user_id=current_user.id)\
                .with_for_update().all()
            
            if not cart_items:
                raise ValueError("Cart is empty - no items to process")

            # Validate stock again with row locks
            for item in cart_items:
                product = Product.query.filter_by(id=item.product_id)\
                    .with_for_update().first()
                    
                if not product:
                    raise ValueError(f"Product {item.product_id} no longer available")
                
                if item.quantity > product.quantity:
                    available = product.quantity
                    requested = item.quantity
                    raise ValueError(
                        f"{product.name}: Only {available} left (you ordered {requested})"
                    f"Please adjust your cart and try again"
                    )

                # Update product quantity atomically
                product.quantity -= item.quantity
                db.session.add(product)

            # Create order
            subtotal = sum(item.product.price * item.quantity for item in cart_items)
            coupon_discount = 0.0
            coupon_code = None
            applied_coupon = session.get("applied_coupon")
            
            if applied_coupon:
                coupon = Coupon.query.filter_by(code=applied_coupon["code"]).first()
                if coupon and coupon.is_valid(datetime.now(ist), subtotal):
                    coupon_discount = applied_coupon["discount"]
                    coupon.used_count += 1
                    db.session.add(coupon)
                    coupon_code = coupon.code

            # Billing address handling (existing code)
            billing_address_id = session.get("billing_address_id")
            if not billing_address_id:
                raise ValueError("Billing address not selected")

            billing_address = BillingAddress.query.get(billing_address_id)
            if not billing_address:
                raise ValueError("Billing address not found")

            billing_address_formatted = (
                f"{billing_address.name}, {billing_address.mobile_number}, "
                f"{billing_address.street}, {billing_address.district}, "
                f"{billing_address.state.name}, {billing_address.country}, {billing_address.pincode}"
            )

            product_list = [
                {
                    "product_id": item.product_id,
                    "name": item.product.name,
                    "quantity": item.quantity,
                    "unit_price": item.product.price,
                    "total_price": item.product.price * item.quantity,
                }
                for item in cart_items
            ]
            
            
            order = Order(
                user_id=current_user.id,
                user_name=current_user.username,
                user_email=current_user.email,
                billing_address=billing_address_formatted,
                products = json.dumps([{
                    "product_id": item.product_id,
                    "name": item.product.name,
                    "quantity": item.quantity,
                    "unit_price": item.product.price,
                }for item in cart_items]),
                total_amount=subtotal,
                currency="INR",
                order_id=order_id,
                razorpay_payment_id=payment_id,
                razorpay_signature=signature,
                amount=subtotal - coupon_discount,
                payment_status="Paid",
                created_at=datetime.now(ist),
                coupon_code=coupon_code,
                discount_applied=coupon_discount,
            )
            db.session.add(order)

            # Clear cart items
            CartItem.query.filter_by(user_id=current_user.id).delete()
            order.set_products(product_list)
            db.session.commit()
        
        # Post-transaction success handling
        session.pop("applied_coupon", None)
        session.pop("billing_address_id", None)

        # Get state information
        business_state_code = app.config["BUSINESS_STATE_CODE"]
        customer_state_code = billing_address.state.code
        is_ut = customer_state_code in app.config['UNION_TERRITORY_STATE_CODES']

        product_list = []
        total_gst = {
            'cgst': 0.0,
            'sgst': 0.0,
            'utgst': 0.0,
            'igst': 0.0,
            'total': 0.0
        }

        for item in cart_items:
            product = item.product
            quantity = item.quantity
            unit_price = product.price
            mrp_price = product.MRP_price if product.MRP_price else unit_price
            total_price = unit_price * quantity
            
            # GST Calculation
            gst_rate = product.gst_rate
            gst_details = {
                'rate': gst_rate,
                'cgst': 0.0,
                'sgst': 0.0,
                'utgst': 0.0,
                'igst': 0.0
            }

            if gst_rate > 0:
                taxable_value = total_price / (1 + (gst_rate / 100))
                tax_amount = total_price - taxable_value

                if customer_state_code == business_state_code:
                    if is_ut:
                        gst_details['cgst'] = tax_amount / 2
                        gst_details['utgst'] = tax_amount / 2
                    else:
                        gst_details['cgst'] = tax_amount / 2
                        gst_details['sgst'] = tax_amount / 2
                else:
                    gst_details['igst'] = tax_amount

                # Round values
                gst_details = {k: round(v, 2) for k, v in gst_details.items()}

            # Update totals
            total_gst['cgst'] += gst_details['cgst']
            total_gst['sgst'] += gst_details['sgst']
            total_gst['utgst'] += gst_details['utgst']
            total_gst['igst'] += gst_details['igst']
            total_gst['total'] += sum(gst_details.values())

            product_list.append({
                "product_id": product.id,
                "name": product.name,
                "quantity": quantity,
                "unit_price": unit_price,
                "mrp_price": mrp_price,
                "total_price": total_price,
                "gst": gst_details
            })

        # Calculate MRP totals
        mrp_total = sum(item['mrp_price'] * item['quantity'] for item in product_list)
        store_discount = mrp_total - subtotal

        return render_template(
            "success.html",
            order=order,
            billing_address=order.billing_address,
            coupon_discount=coupon_discount,
            subtotal=subtotal,
            mrp_total=mrp_total,
            store_discount=store_discount,
            products=product_list,
            total_gst=total_gst,
            business_state_code=business_state_code,
            customer_state_code=customer_state_code,
            is_ut=is_ut
        )

    except Exception as e:
        logger.error(f"Payment success error: {str(e)}", exc_info=True)
        db.session.rollback()
        flash(f"Order failed: {str(e)}", "danger")
        return redirect(url_for("cart"))


@app.route("/payment/failure")
@login_required
def payment_failure():
    flash("Payment failed. Please try again.", "danger")
    return redirect(url_for("cart"))

@app.route("/request_refund/<int:order_id>", methods=["POST"])
@login_required
def request_refund(order_id):
    try:
        # Find the order by ID
        order = Order.query.get_or_404(order_id)

        # Ensure the user is the owner of the order or an admin
        if order.user_id != current_user.id and not current_user.is_admin:
            abort(403)  # Unauthorized access

        # Check if a refund already exists for this order
        existing_refund = Refund.query.filter_by(order_id=order_id).first()
        if existing_refund:
            flash("A refund request already exists for this order.", "info")
            return redirect(url_for("order_detail", order_id=order_id))

        # Create a new refund record
        refund = Refund(
            razorpay_refund_id="",  # Initially empty, to be filled after successful Razorpay processing
            order_id=order_id,
            reason=request.form.get("reason"),
            amount=order.total_amount,  # Assuming full refund for simplicity
            created_at=datetime.now(ist),
            refund_status="Requested",
        )
        db.session.add(refund)
        db.session.commit()

        flash("Refund request submitted successfully.", "success")
        return redirect(url_for("order_detail", order_id=order_id))
    except Exception as e:
        logger.error(f"Error in request_refund: {e}")
        flash(
            "An error occurred while submitting the refund request. Please try again.",
            "danger",
        )
        return redirect(url_for("order_detail", order_id=order_id))
    
@app.route("/process_refund/<int:refund_id>", methods = ["GET", "POST"])
@login_required
def process_refund(refund_id):
    try:
        # Ensure user is admin for refund processing
        if not current_user.is_admin:
            abort(403)  # Unauthorized access

        # Find the refund by ID
        refund = Refund.query.get_or_404(refund_id)
        order = Order.query.get_or_404(refund.order_id)

        # Initiate Razorpay refund
        refund_response = razorpay_client.refund.create(
            {
                "payment_id": order.razorpay_payment_id,
                "amount": int(refund.amount * 100),  # Convert to paise
                "notes": {"reason": refund.reason}  # Notes should be a dictionary
            }
        )

        # Update refund record with Razorpay refund ID and status
        refund.razorpay_refund_id = refund_response["id"]
        refund.refund_status = "Processed"
        db.session.commit()

        flash("Refund processed successfully.", "success")
        return redirect(url_for("order_detail", order_id=refund.order_id))
    except Exception as e:
        logger.error(f"Error in process_refund: {e}")
        flash(
            "An error occurred while processing the refund. Please try again.", "danger"
        )
        return redirect(url_for("order_detail", order_id=refund.order_id))

def generate_otp():
    return str(randint(100000, 999999))

@app.route("/statics/upload/<filename>")
def uploaded_file(filename):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename)

@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegistrationForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        # Store registration data in session
        session["username"] = form.username.data
        session["email"] = form.email.data
        # Hash the password before storing it
        hashed_password = generate_password_hash(form.password.data)
        session["password"] = hashed_password

        session["mobile_number"] = form.mobile_number.data

        # Generate OTP
        otp = generate_otp()
        print(f"Mock OTP for testing: {otp}")  # Log OTP for manual testing

        # Send OTP via email
        msg = Message("OTP Verification", recipients=[form.email.data])
        msg.body = f"Your OTP is: {otp}"
        mail.send(msg)
        

        # Store the OTP in session
        session["otp"] = otp

        # Redirect to OTP verification page
        return redirect(url_for("verify_otp"))

    return render_template("register.html", form=form, newsletter_form=newsletter_form)

@app.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp():
    form = OTPForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        # Check if OTP is correct
        otp = session.get('otp')
        if form.otp.data == otp:
            # OTP is correct, proceed with registration
            username = session.get('username')
            email = session.get('email')
            password = session.get('password')
            mobile_number = session.get('mobile_number')
            otp_secret = generate_otp()  # Generate OTP secret here

            # Create a new user object with all the data
            new_user = User(username=username, email=email, password=password,
                            otp_secret=otp_secret,
                            mobile_number=mobile_number)

            # Add the new user to the database
            db.session.add(new_user)
            db.session.commit()

            # Clear session data
            session.clear()

            flash('OTP verified. Registration successful!', 'success')
            return redirect(url_for('login'))
        else:
            flash('Invalid OTP. Please try again.', 'danger')

    return render_template('verify_otp.html', form=form, newsletter_form=newsletter_form)



@app.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute", error_message="Too many login attempts. Try again in 1 minute.")
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    form = LoginForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data

        user = User.query.filter_by(username=username).first()
        print("Retrieved User:", user)

        if user and check_password_hash(user.password, password):
            login_user(user, remember=form.remember_me.data)
            return redirect(url_for("index"))
        else:
            flash("Invalid username or password. Please try again.", "danger")

    return render_template("login.html", form=form, newsletter_form=newsletter_form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route("/edit-profile", methods=["GET", "POST"])
@login_required
def edit_profile():
    form = EditProfileForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        # Update user profile data
        user = User.query.filter_by(id=current_user.id).first()
        user.username = form.username.data
        user.mobile_number = form.mobile_number.data

        # Handle profile picture update
        if form.profile_picture.data:
            profile_picture = form.profile_picture.data
            if profile_picture and allowed_file(profile_picture.filename):
                filename = secure_filename(profile_picture.filename)
                profile_picture_path = os.path.join(
                    app.config["UPLOAD_FOLDER"], filename
                )
                profile_picture.save(profile_picture_path)
                user.profile_picture = profile_picture_path

        # Check if email is being changed
        if user.email != form.email.data:
            # Generate OTP
            otp = generate_otp()

            # Send OTP via email
            msg = Message("OTP Verification", recipients=[form.email.data])
            msg.body = f"Your OTP is: {otp}"
            mail.send(msg)

            # Store the new email and OTP in session
            session["new_email"] = form.email.data
            session["otp"] = otp

            # Redirect to OTP verification page
            return redirect(url_for("verify_otp_edit"))

        # If email is not being changed, save changes directly
        db.session.commit()

        flash("Profile updated successfully!", "success")
        return redirect(url_for("edit_profile"))

    # Pre-populate form fields with current user data
    form.username.data = current_user.username
    form.email.data = current_user.email
    form.mobile_number.data = current_user.mobile_number
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template("edit_profile.html", form=form, newsletter_form=newsletter_form, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)

@app.route("/verify-otp-edit", methods=["GET", "POST"])
def verify_otp_edit():
    form = OTPForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        otp = session.get("otp")
        if form.otp.data == otp:
            # OTP is correct, proceed with updating email
            user = User.query.filter_by(id=current_user.id).first()
            user.email = session.get("new_email")
            db.session.commit()

            flash("Email updated successfully!", "success")
            session.pop("new_email")  # Remove the temporary email from the session
            session.pop("otp")  # Remove the OTP from the session
            return redirect(url_for("edit_profile"))
        else:
            flash("Invalid OTP. Please try again.", "danger")

    return render_template(
        "verify_otp_edit.html", form=form, newsletter_form=newsletter_form
    )
    
@app.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    form = ResetPasswordForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        # Check if user with provided email exists
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            # Generate OTP
            otp = generate_otp()

            # Send OTP via email
            msg = Message(
                "OTP Verification for Password Reset", recipients=[form.email.data]
            )
            msg.body = f"Your OTP for password reset is: {otp}"
            mail.send(msg)

            # Store the email and OTP in session
            session["reset_email"] = form.email.data
            session["reset_otp"] = otp

            # Redirect to OTP verification page
            return redirect(url_for("verify_reset_otp"))

        flash("No user found with this email address.", "danger")

    return render_template("reset_password.html", form=form, newsletter_form=newsletter_form)

@app.route("/verify-reset-otp", methods=["GET", "POST"])
def verify_reset_otp():
    form = OTPForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        otp = session.get("reset_otp")
        if form.otp.data == otp:
            # OTP is correct, proceed with password reset
            return redirect(url_for("reset_password_complete"))
        else:
            flash("Invalid OTP. Please try again.", "danger")

    return render_template("verify_reset_otp.html", form=form, newsletter_form=newsletter_form)

@app.route("/reset-password-complete", methods=["GET", "POST"])
def reset_password_complete():
    form = NewPasswordForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        # Retrieve the user using the email stored in session
        user = User.query.filter_by(email=session.get("reset_email")).first()
        # Update user's password
        user.password = generate_password_hash(form.new_password.data)
        db.session.commit()

        # Clear session data
        session.pop("reset_email")
        session.pop("reset_otp")

        flash("Password reset successfully!", "success")
        return redirect(url_for("login"))

    return render_template("reset_password_complete.html", form=form, newsletter_form=newsletter_form)


@app.route("/my_orders")
@login_required
def my_orders():
    page = request.args.get("page", 1, type=int)

    # Fetch the user's orders, ordered by the most recent first
    orders_query = Order.query.filter_by(user_id=current_user.id).order_by(
        Order.id.desc()
    )

    # Paginate the orders query
    orders = orders_query.paginate(page=page, per_page=app.config["ORDERS_PER_PAGE"], error_out=False)

    # Prepare a list of order details
    order_items_list = []
    for order in orders.items:
        product_list = order.get_products()  # Deserialize products field
        order_items = []

        # Fetch details for each product and append it to order_items
        for product in product_list:
            if 'total_price' not in product:
                product['total_price'] = product['quantity'] * product['unit_price']
            product_id = product['product_id']
            quantity = product['quantity']
            item = {
                'product': Product.query.get_or_404(product_id),
                'quantity': quantity,
                'unit_price': product['unit_price'],
                'total_price': product.get('total_price', product['quantity'] * product['unit_price'])
            }
            order_items.append(item)

        # Append the order_items to the list
        order_items_list.append({
            'order': order,
            'items': order_items
        })
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template("my_orders.html", orders=orders, order_items_list=order_items_list, cart_items=cart_items,cart_item_count=cart_item_count, total_price=total_price,)

@app.route("/order/<int:order_id>")
@login_required
def order_detail(order_id):
    # Fetch the order or return a 404 error if not found
    order = Order.query.get_or_404(order_id)
    
    # Check if the user has permission to view this order
    if order.user_id != current_user.id and not current_user.is_admin:
        abort(403)  # Unauthorized access

    # Get the products from the order
    product_list = order.get_products()  # Deserialize products field

    # Fetch related order items
    order_items = []
    for product in product_list:
        if "total_price" not in product:
            product["total_price"] = product["quantity"] * product["unit_price"]
        product_id = product['product_id']
        quantity = product['quantity']
        item = {
            'product': Product.query.get_or_404(product_id),
            'quantity': quantity,
            'unit_price': product['unit_price'],
            'total_price': product['total_price']
        }
        order_items.append(item)

    # Get the created_at timestamp from the order
    created_at = order.created_at
    
    # Get billing address directly from the order
    billing_address = order.get_billing_address()
    
    # Include product images for each product
    for item in order_items:
        product = item['product']
        item['product_images'] = [img.image_url for img in product.images] if product.images else []
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template(
        "order_detail.html",
        order=order,
        order_items=order_items,
        billing_address=billing_address,
        created_at=created_at, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)

@app.route("/billing_address", methods=["GET", "POST"])
@login_required
def billing_address():
    states = State.query.all()  # Get all states from database
    previous_addresses = current_user.billing_addresses

    if request.method == "POST":
        name = request.form["name"]
        mobile_number = request.form["mobile_number"]
        country = request.form["country"]
        state_id = request.form["state_id"]  # Changed from 'state'
        district = request.form["district"]
        street = request.form["street"]
        pincode = request.form["pincode"]

        # Get state object
        state = State.query.get(state_id)
        if not state:
            flash("Invalid state selected", "danger")
            return redirect(url_for("billing_address"))

        new_address = BillingAddress(
            user_id=current_user.id,
            name=name,
            mobile_number=mobile_number,
            country=country,
            district=district,
            street=street,
            pincode=pincode,
            state=state  # Assign state relationship
        )

        db.session.add(new_address)

        try:
            db.session.commit()
            flash("Billing address added successfully.", "success")
            logging.info("Billing address added successfully.")
        except SQLAlchemyError as e:
            db.session.rollback()
            flash("Failed to add billing address. Please try again.", "error")
            logging.error(f"Failed to add billing address. Error: {e}")

        return redirect(request.referrer or url_for("index"))
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)

    return render_template(
        "billing_address.html", previous_addresses=previous_addresses, states=states, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)
@app.route('/manage_billing_addresses')
@login_required
def manage_billing_addresses():
    addresses = current_user.billing_addresses
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template('manage_billing_addresses.html', addresses=addresses, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)

@app.route("/edit_billing_address/<int:address_id>", methods=["GET", "POST"])
@login_required
def edit_billing_address(address_id):
    address = BillingAddress.query.get_or_404(address_id)
    if address.user_id != current_user.id:
        abort(403)  # Unauthorized access

    states = State.query.all()  # Retrieve all states for dropdown

    if request.method == "POST":
        # Extract form data
        name = request.form["name"]
        mobile_number = request.form["mobile_number"]
        country = request.form["country"]
        state_id = request.form["state_id"]  # Get state ID from form
        district = request.form["district"]
        street = request.form["street"]
        pincode = request.form["pincode"]

        # Validate selected state
        state = State.query.get(state_id)
        if not state:
            flash("Invalid state selected", "danger")
            return redirect(url_for("edit_billing_address", address_id=address_id))

        # Update address fields
        address.name = name
        address.mobile_number = mobile_number
        address.country = country
        address.district = district
        address.street = street
        address.pincode = pincode
        address.state = state  # Set state relationship

        try:
            db.session.commit()
            flash("Billing address updated successfully.", "success")
            logging.info(f"Billing address {address_id} updated successfully.")
        except SQLAlchemyError as e:
            db.session.rollback()
            flash("Failed to update billing address. Please try again.", "error")
            logging.error(f"Error updating billing address {address_id}: {e}")

        return redirect(url_for("manage_billing_addresses"))
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    # Pre-populate form with existing data in GET request
    return render_template(
        "edit_billing_address.html",
        address=address,
        states=states, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)

@app.route('/delete_billing_address/<int:address_id>', methods=['POST'])
@login_required
def delete_billing_address(address_id):
    address = BillingAddress.query.get_or_404(address_id)
    if address.user_id != current_user.id:
        abort(403)  # Unauthorized access
    db.session.delete(address)
    try:
        db.session.commit()
        flash('Billing address deleted successfully.', 'success')
    except SQLAlchemyError:
        db.session.rollback()
        flash('Failed to delete billing address. Please try again.', 'error')
    return redirect(url_for('manage_billing_addresses'))

@app.route("/admin/dashboard")
@login_required
def admin_dashboard():
    page = request.args.get("page", 1, type=int)
    products = Product.query.paginate(page=page, per_page=5)
    carousel_products = Product.query.filter_by(carousel_display=True).all()

    if not current_user.is_admin:
        abort(403)  # Unauthorized access

    # Get daily sales
    today_sales = (
        db.session.query(func.sum(Order.total_amount))
        .filter(func.date(Order.created_at) == date.today())
        .scalar()
        or 0.0
    )

    # Get total payments (sum of payments with status "Paid")
    total_payments = (
        db.session.query(func.sum(Order.amount))
        .filter(Order.payment_status == "Paid")
        .scalar()
        or 0.0
    )

    # Get total orders
    total_orders = Order.query.count()

    
    recent_orders = Order.query.order_by(Order.created_at.desc()).paginate(
    page=page, per_page=10
)
    # Initialize products_query properly
    products_query = Product.query

    # Exclude products with carousel_display set to True from the main products list
    products_query = products_query.filter(Product.carousel_display == False)
    
    # Convert timestamps to IST
    for order in recent_orders.items:
        order.created_at = order.created_at
    
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template(
        "admin/admin_dashboard.html",
        today_sales=today_sales,
        total_payments=total_payments,
        total_orders=total_orders,
        recent_orders=recent_orders,
        carousel_products=carousel_products,
        products=products, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)

@app.route("/admin/sales_analytics")
@login_required
def sales_analytics():
    if not current_user.is_admin:
        abort(403)

    # Time-based sales analysis
    time_period = request.args.get('period', 'monthly')
    
    if time_period == 'daily':
        date_format = 'YYYY-MM-DD'
    elif time_period == 'weekly':
        date_format = 'IYYY-IW'  # ISO week format
    else:  # monthly
        date_format = 'YYYY-MM'

    # Sales trend analysis
    sales_trend = db.session.query(
        func.to_char(Order.created_at, date_format).label("period"),
        func.sum(Order.total_amount).label('total_sales'),
        func.count(Order.id).label('order_count'),
        func.avg(Order.total_amount).label('avg_order_value')
    ).group_by('period').order_by('period').all()

    # Process product statistics in Python
    all_orders = Order.query.all()
    product_stats = {}
    
    for order in all_orders:
        try:
            products = json.loads(order.products)
            for item in products:
                if 'total_price' not in item:
                    item['total_price'] = item['quantity'] * item['unit_price']
                product = Product.query.get(item['product_id'])
                if product:
                    key = (product.id, product.name, product.category)
                    if key not in product_stats:
                        product_stats[key] = {
                            'total_revenue': 0.0,
                            'total_quantity': 0
                        }
                    product_stats[key]['total_revenue'] += float(item['total_price'])
                    product_stats[key]['total_quantity'] += item['quantity']
        except json.JSONDecodeError:
            continue

    # Convert to sorted list and limit to top 10
    product_stats = sorted(
        [{
            'id': key[0],
            'name': key[1],
            'category': key[2],
            'total_revenue': stats['total_revenue'],
            'total_quantity': stats['total_quantity']
        } for key, stats in product_stats.items()],
        key=lambda x: x['total_revenue'],
        reverse=True
    )[:10]

    # Process category statistics
    category_stats = {}
    for order in all_orders:
        try:
            products = json.loads(order.products)
            for item in products:
                if 'total_price' not in item:
                    item['total_price'] = item['quantity'] * item['unit_price']
                product = Product.query.get(item['product_id'])
                if product:
                    if product.category not in category_stats:
                        category_stats[product.category] = {
                            'total_revenue': 0.0,
                            'order_count': set(),
                            'total_quantity': 0
                        }
                    category_stats[product.category]['total_revenue'] += float(item['total_price'])
                    category_stats[product.category]['order_count'].add(order.id)
                    category_stats[product.category]['total_quantity'] += item['quantity']
        except json.JSONDecodeError:
            continue

    # Prepare category data
    category_data = []
    for category, stats in category_stats.items():
        category_data.append({
            'category': category,
            'total_revenue': stats['total_revenue'],
            'order_count': len(stats['order_count']),
            'avg_order_value': stats['total_revenue'] / len(stats['order_count']) if stats['order_count'] else 0
        })

    # Customer analytics
    customer_stats = db.session.query(
        User.id,
        User.username,
        func.count(Order.id).label('order_count'),
        func.sum(Order.total_amount).label('total_spent'),
        func.avg(Order.total_amount).label('avg_order_value')
    ).join(Order).group_by(User.id).order_by(desc('total_spent')).limit(10).all()

    # Key metrics
    total_sales = sum(float(order.total_amount) for order in all_orders)
    avg_order_value = total_sales / len(all_orders) if all_orders else 0
    total_products_sold = sum(
        sum(item['quantity'] for item in json.loads(order.products))
        for order in all_orders
        if order.products
    )

    return render_template('admin/sales_analytics.html',
                         trend_labels=[result.period for result in sales_trend],
                         trend_data={
                             'total_sales': [float(result.total_sales) for result in sales_trend],
                             'order_count': [result.order_count for result in sales_trend],
                             'avg_order_value': [float(result.avg_order_value) for result in sales_trend]
                         },
                         product_stats=product_stats,
                         category_stats=category_data,
                         customer_stats=customer_stats,
                         total_sales=total_sales,
                         avg_order_value=avg_order_value,
                         total_products_sold=total_products_sold,
                         time_period=time_period)

# Contactsection
@app.route("/contact", methods=["GET", "POST"])
def contact():
    form = ContactMessageForm()
    newsletter_form = NewsletterSubscriptionForm()
    if form.validate_on_submit():
        # Create a ContactMessage instance
        contact_message = ContactMessage(
            name=form.name.data, email=form.email.data, message=form.message.data
        )
        db.session.add(contact_message)
        db.session.commit()
        
        # Send contact email
        send_contact_email(
            name=form.name.data,
            email=form.email.data,
            subject="New Contact Message",
            message=form.message.data
        )
        flash("Your message has been sent successfully!", "success")
        return redirect(url_for("contact"))
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)

    return render_template("contact.html", form=form, newsletter_form=newsletter_form, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)





@app.route("/add_to_cart/<int:product_id>", methods=["POST"])
@login_required
def add_to_cart(product_id):
    try:
        product = Product.query.get_or_404(product_id)
        quantity = int(request.form.get("quantity", 1))
        
        if quantity < 1:
            flash("Invalid quantity requested", "danger")
            return redirect(request.referrer)

        # Calculate total requested quantity
        existing_cart_qty = sum(
            item.quantity for item in current_user.cart_items 
            if item.product_id == product_id
        )
        requested_total = existing_cart_qty + quantity

        # Validate against available stock
        if requested_total > product.quantity:
            available = product.quantity - existing_cart_qty
            flash(f"Only {available} item(s) available for {product.name}", "warning")
            return redirect(request.referrer)

        # Update or create cart item
        cart_item = CartItem.query.filter_by(
            user_id=current_user.id, 
            product_id=product_id
        ).first()

        if cart_item:
            cart_item.quantity += quantity
        else:
            cart_item = CartItem(
                user_id=current_user.id,
                product_id=product_id,
                quantity=quantity
            )
            db.session.add(cart_item)

        db.session.commit()
        flash(f"{product.name} added to cart", "success")

    except SQLAlchemyError as e:
        db.session.rollback()
        flash("Failed to update cart. Please try again.", "danger")
        app.logger.error(f"Cart update error: {str(e)}")
    
    return redirect(request.referrer or url_for("index"))


def calculate_total_price():
    total_price = 0
    cart_items = CartItem.query.filter_by(user_id=current_user.id).all()
    for cart_item in cart_items:
        total_price += cart_item.quantity * cart_item.product.price
    return total_price

@app.route("/update_cart/<int:cart_item_id>", methods=["POST"])
@login_required
def update_cart(cart_item_id):
    try:
        cart_item = CartItem.query.get_or_404(cart_item_id)
        if cart_item.user_id != current_user.id:
            abort(403)

        new_quantity = int(request.form.get("quantity", 1))
        product = Product.query.get(cart_item.product_id)

        if not product:
            flash("Product not found", "error")
            return redirect(url_for('cart'))  # Redirect to the cart page or a suitable page

        # Validate new quantity
        if new_quantity < 0:
            flash("Invalid quantity", "error")
            return redirect(url_for('cart'))  # Redirect to the cart page or a suitable page

        # Check available stock considering other cart items
        other_cart_qty = sum(
            item.quantity for item in current_user.cart_items 
            if item.product_id == product.id and item.id != cart_item_id
        )
        max_allowed = product.quantity - other_cart_qty

        if new_quantity > max_allowed:
            flash(f"Only {max_allowed} available in stock", "error")
            return redirect(url_for('cart'))  # Redirect to the cart page or a suitable page

        # Update quantity
        cart_item.quantity = new_quantity
        db.session.commit()

        # Recalculate totals
        total_price = sum(
            item.product.price * item.quantity 
            for item in current_user.cart_items
        )
        item_total = cart_item.product.price * new_quantity

        flash("Cart updated successfully", "success")
        return redirect(url_for('cart'))  # Redirect to the cart page with success message

    except SQLAlchemyError as e:
        db.session.rollback()
        app.logger.error(f"Cart update error: {str(e)}")
        flash("Database error updating cart", "error")
        return redirect(url_for('cart'))


@app.route("/remove_from_cart/<int:cart_item_id>", methods=["POST"])
@login_required
def remove_from_cart(cart_item_id):
    cart_item = CartItem.query.get_or_404(cart_item_id)
    if cart_item.user_id == current_user.id:
        db.session.delete(cart_item)
        db.session.commit()
        total_price = calculate_total_price()  # Calculate total price after removal
        return jsonify({"total_price": total_price}), 200
    return jsonify({"error": "Unauthorized access."}), 403

@app.route('/add_to_favorites/<int:product_id>', methods=['POST'])
@login_required
def add_to_favorites(product_id):
    favorite_item = FavoriteItem.query.filter_by(user_id=current_user.id, product_id=product_id).first()
    if not favorite_item:
        favorite_item = FavoriteItem(user_id=current_user.id, product_id=product_id)
        db.session.add(favorite_item)
        db.session.commit()
        flash('Product added to favorites successfully.', 'success')   # Flash success message
    else:
        flash('Product is already in favorites.', 'warning')           # Flash warning message
    
    # Redirect back to the same category page
    return redirect(request.referrer )


@app.route("/remove_from_favorites/<int:favorite_item_id>", methods=["POST"])
@login_required
def remove_from_favorites(favorite_item_id):
    favorite_item = FavoriteItem.query.get_or_404(favorite_item_id)
    if favorite_item.user_id == current_user.id:
        db.session.delete(favorite_item)
        db.session.commit()
        return jsonify({"message": "Product removed from favorites successfully."})
    return jsonify({"error": "Unauthorized access."}), 403

# Update Cart and Favorites routes to handle advanced features
@app.route("/cart")
@login_required
def cart():
    cart_items = current_user.cart_items
    mrp_total = sum(item.product.MRP_price * item.quantity for item in cart_items)
    subtotal = sum(item.product.price * item.quantity for item in cart_items)
    store_discount = mrp_total - subtotal

    # Coupon calculations
    coupon_discount = 0
    coupon_code = None
    applied_coupon = session.get("applied_coupon")
    if applied_coupon:
        coupon_discount = applied_coupon.get("discount", 0)
        coupon_code = applied_coupon.get("code")

    final_total = max(subtotal - coupon_discount, 0)
    # Pass the count of cart items to the template
    cart_item_count = len(cart_items)
     # Fetch unique categories from the database
    categories = db.session.query(Product.category).distinct().all()
    categories = [category[0] for category in categories]
    return render_template(
        "cart.html",
        cart_items=cart_items,
        mrp_total=mrp_total,
        subtotal=subtotal,
        store_discount=store_discount,
        coupon_discount=coupon_discount,
        final_total=final_total,
        coupon_code=coupon_code,
        cart_item_count=len(cart_items),
        categories=categories,
    )
    
@app.route("/cart/count")
@login_required
def cart_count():
    cart_items_count = len(current_user.cart_items)
    return jsonify({"count": cart_items_count})
    
@app.route('/favorites')
@login_required
def favorites():
    favorite_items = current_user.favorite_items
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    # Fetch unique categories from the database
    categories = db.session.query(Product.category).distinct().all()
    categories = [category[0] for category in categories]
    return render_template('favorites.html', favorite_items=favorite_items, categories=categories, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)


@app.route("/profile")
@login_required
def profile():
    user = current_user
    # Get purchase history data for the graph
    purchase_history = db.session.query(
        func.to_char(Order.created_at, "YYYY-MM").label("month"),
        func.sum(Order.total_amount).label('total')
    ).filter(
        Order.user_id == user.id
    ).group_by(
        func.to_char(Order.created_at, "YYYY-MM")
    ).order_by(
        func.to_char(Order.created_at, "YYYY-MM")
    ).all()

    # Format data for Chart.js
    purchase_labels = [entry.month for entry in purchase_history]
    purchase_data = [float(entry.total) for entry in purchase_history]

    recent_orders = Order.query.filter_by(user_id=user.id).order_by(Order.created_at.desc()).limit(3).all()
    favorite_items = FavoriteItem.query.filter_by(user_id=user.id).limit(4).all()
    billing_addresses = BillingAddress.query.filter_by(user_id=user.id).limit(2).all()
    
    recently_viewed_ids = request.cookies.get('recently_viewed', '')
    recently_viewed_products = []
    if recently_viewed_ids:
        product_ids = [int(id) for id in recently_viewed_ids.split(',')[-4:]]
        recently_viewed_products = Product.query.filter(Product.id.in_(product_ids)).all()
    cart_items = current_user.cart_items if current_user.is_authenticated else []
    cart_item_count = len(cart_items)
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render_template(
        "profile.html",
        user=user,
        recent_orders=recent_orders,
        favorite_items=favorite_items,
        billing_addresses=billing_addresses,
        recently_viewed_products=recently_viewed_products,
        purchase_labels=purchase_labels,purchase_data=purchase_data, cart_items=cart_items,cart_item_count=cart_item_count,total_price=total_price,)
    
# Add this route to your app.py
@app.route("/gst_returns/<month>")
@login_required
def generate_gst_returns(month):
    if not current_user.is_admin:
        abort(403)

    try:
        # Validate month format
        if len(month) != 6 or not month.isdigit():
            raise ValueError
        month_num = int(month[:2])
        year_num = int(month[2:])
        start_date = datetime(year_num, month_num, 1)
        end_date = (
            datetime(year_num, month_num + 1, 1)
            if month_num != 12
            else datetime(year_num + 1, 1, 1)
        )
    except ValueError:
        abort(400, description="Invalid month format. Use MMYYYY (e.g., 032024)")

    # Get business state from database
    business_state = State.query.filter_by(
        code=app.config["BUSINESS_STATE_CODE"]
    ).first()
    if not business_state:
        abort(500, description="Business state not configured properly")

    # Fetch orders with related data
    orders = (
        Order.query.filter(Order.created_at >= start_date, Order.created_at < end_date)
        .options(
            db.joinedload(Order.billing_address).joinedload(BillingAddress.state_rel)
        )
        .all()
    )

    tax_data = {}

    for order in orders:
        if not order.billing_address:
            continue

        # Handle both old and new state data
        if order.billing_address.state_rel:
            customer_state = order.billing_address.state_rel
        else:
            # Fallback to legacy state name lookup
            customer_state = State.query.filter_by(
                name=order.billing_address.state
            ).first()

        if not customer_state:
            customer_state_code = "99"  # Unknown state
        else:
            customer_state_code = customer_state.code

        for item in order.get_products():
            product = Product.query.get(item["product_id"])
            if not product:
                continue

            # Calculate values
            quantity = item["quantity"]
            unit_price = item["unit_price"]
            taxable_value = round(quantity * unit_price, 2)
            gst_rate = int(round(product.gst_rate, 0))  # Ensure integer rate

            # Determine supply type
            if customer_state_code == business_state.code:
                supply_type = "INTRA"
                pos_code = business_state.code
            else:
                supply_type = "INTER"
                pos_code = customer_state_code if customer_state else "99"

            tax_key = (supply_type, pos_code, gst_rate)

            if tax_key not in tax_data:
                tax_data[tax_key] = {
                    "sply_ty": supply_type,
                    "pos": pos_code,
                    "rt": gst_rate,
                    "txval": 0.0,
                    "iamt": 0.0,
                    "camt": 0.0,
                    "samt": 0.0,
                }

            # Calculate tax amounts
            tax_amount = round(taxable_value * gst_rate / 100, 2)

            if supply_type == "INTER":
                tax_data[tax_key]["iamt"] += tax_amount
            else:
                tax_data[tax_key]["camt"] += tax_amount / 2
                tax_data[tax_key]["samt"] += tax_amount / 2

            tax_data[tax_key]["txval"] += taxable_value

    # Process and format the data
    b2cs_entries = []
    for key in sorted(tax_data.keys()):
        entry = tax_data[key]
        # Round to whole numbers as per GST rules
        formatted_entry = {
            "sply_ty": entry["sply_ty"],
            "pos": entry["pos"],
            "rt": entry["rt"],
            "txval": round(entry["txval"]),
            "iamt": round(entry["iamt"]),
            "camt": round(entry["camt"]),
            "samt": round(entry["samt"]),
        }
        b2cs_entries.append(formatted_entry)

    # Create final JSON structure
    gst_return = {
        "gstin": app.config["BUSINESS_GSTIN"],
        "fp": month,
        "b2cs": b2cs_entries,
    }

    # Create response
    response = jsonify(gst_return)
    response.headers["Content-Type"] = "application/json"
    response.headers.add(
        "Content-Disposition", f"attachment; filename=gstr1_b2cs_{month}.json"
    )
    return response

@app.route('/gst_returns_list')
@login_required
def gst_returns_list():
    if not current_user.is_admin:
        abort(403)

    # Get distinct months with GST returns in MMYYYY format
    months = db.session.query(
        func.to_char(Order.created_at, 'MMYYYY').label('month_year')  # Changed to MMYYYY
    ).group_by('month_year').order_by(desc('month_year')).all()

    # Format months for display
    formatted_months = []
    for m in months:
        try:
            # Extract month (first 2 digits) and year (last 4 digits)
            month_num = m.month_year[:2]
            year_num = m.month_year[2:]
            
            # Convert to month name
            month_name = datetime.strptime(month_num, '%m').strftime('%B')
            formatted = f"{month_name} {year_num}"
            
            formatted_months.append({
                'display': formatted,
                'value': m.month_year
            })
        except Exception as e:
            app.logger.error(f"Error formatting month: {m.month_year}, error: {str(e)}")
            continue

    return render_template('admin/gst_returns_list.html', 
                         months=formatted_months)

@app.route("/view_gst_returns/<month>")
@login_required
def view_gst_returns(month):
    if not current_user.is_admin:
        abort(403)

    try:
        # Validate month format
        if len(month) != 6 or not month.isdigit():
            raise ValueError
        month_num = int(month[:2])
        year_num = int(month[2:])
        start_date = datetime(year_num, month_num, 1)
        end_date = (
            datetime(year_num, month_num + 1, 1)
            if month_num != 12
            else datetime(year_num + 1, 1, 1)
        )
    except ValueError:
        flash("Invalid month format. Use MMYYYY (e.g., 032024)", "danger")
        return redirect(url_for("admin_dashboard"))

    # Get business state from config
    business_state = State.query.filter_by(
        code=app.config["BUSINESS_STATE_CODE"]
    ).first()
    if not business_state:
        flash("Business state not configured properly", "danger")
        return redirect(url_for("admin_dashboard"))

    # Fetch orders
    orders = Order.query.filter(
        Order.created_at >= start_date, Order.created_at < end_date
    ).all()

    tax_data = {}
    total = {"txval": 0.0, "iamt": 0.0, "camt": 0.0, "samt": 0.0}

    for order in orders:
        if not order.billing_address:
            continue

        # Parse state from address string
        try:
            address_parts = order.billing_address.split(", ")
            state_name = address_parts[4].strip() if len(address_parts) >= 5 else None
            customer_state = (
                State.query.filter_by(name=state_name).first() if state_name else None
            )
        except Exception as e:
            customer_state = None

        customer_state_code = customer_state.code if customer_state else "99"

        for item in order.get_products():
            product = Product.query.get(item["product_id"])
            if not product:
                continue

            # Calculate values
            quantity = item["quantity"]
            unit_price = item["unit_price"]
            taxable_value = quantity * unit_price
            gst_rate = int(round(product.gst_rate, 0))

            # Determine supply type
            if customer_state_code == business_state.code:
                supply_type = "INTRA"
                pos_code = business_state.code
            else:
                supply_type = "INTER"
                pos_code = customer_state_code

            tax_key = (supply_type, pos_code, gst_rate)

            if tax_key not in tax_data:
                tax_data[tax_key] = {
                    "supply_type": supply_type,
                    "pos_code": pos_code,
                    "gst_rate": gst_rate,
                    "txval": 0.0,
                    "iamt": 0.0,
                    "camt": 0.0,
                    "samt": 0.0,
                }

            # Calculate tax amounts
            tax_amount = taxable_value * gst_rate / 100

            if supply_type == "INTER":
                tax_data[tax_key]["iamt"] += tax_amount
            else:
                tax_data[tax_key]["camt"] += tax_amount / 2
                tax_data[tax_key]["samt"] += tax_amount / 2

            tax_data[tax_key]["txval"] += taxable_value

    # Prepare display data
    display_data = []
    for key in sorted(tax_data.keys()):
        entry = tax_data[key]
        formatted_entry = {
            "supply_type": entry["supply_type"],
            "pos_code": entry["pos_code"],
            "gst_rate": f"{entry['gst_rate']}%",
            "taxable_value": round(entry["txval"], 2),
            "igst": round(entry["iamt"], 2),
            "cgst": round(entry["camt"], 2),
            "sgst": round(entry["samt"], 2),
        }

        # Update totals
        total["txval"] += entry["txval"]
        total["iamt"] += entry["iamt"]
        total["camt"] += entry["camt"]
        total["samt"] += entry["samt"]

        display_data.append(formatted_entry)

    # Format totals
    formatted_total = {
        "taxable_value": round(total["txval"], 2),
        "igst": round(total["iamt"], 2),
        "cgst": round(total["camt"], 2),
        "sgst": round(total["samt"], 2),
        "total_tax": round(total["iamt"] + total["camt"] + total["samt"], 2),
    }

    # Get all states for code lookup
    states = State.query.all()
    state_map = {state.code: state.name for state in states}

    return render_template(
        "admin/gst_preview.html",
        month=month,
        entries=display_data,
        total=formatted_total,
        business_state=business_state,
        state_map=state_map,
    )
# Error handlers
@login_manager.unauthorized_handler
def unauthorized():
    return render_template('401.html'), 401

@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html', error='Page not found'), 404

@app.errorhandler(403)
def forbidden(error):
    return render_template('403.html', error='Forbidden'), 403

# app.py
@app.errorhandler(500)
def internal_error(error):
    # Get all categories
    all_categories = [c[0] for c in db.session.query(Product.category).distinct().all()]
    
    return render_template(
        '500.html', 
        error='Internal server error',
        categories=all_categories  # Pass categories to template
    ), 500

if __name__ == '__main__':
    app.run(debug=True)
