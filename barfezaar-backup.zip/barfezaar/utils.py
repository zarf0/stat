from flask_mail import Message
from extensions import mail
from flask import current_app
from datetime import datetime
import pytz 
ist = pytz.timezone("Asia/Kolkata")
def send_confirmation_email(email):
    subject = "Subscription Confirmation"
    sender_name = "BARF-E-ZAAR"

    # HTML Body - Modern, minimalist, and luxurious
    html_body = f"""
    <html>
        <head>
            <style>
                body {{
                    font-family: 'Roboto', sans-serif;
                    background-color: #f9f9f9;
                    color: #333;
                    margin: 0;
                    padding: 0;
                }}
                .container {{
                    width: 100%;
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: #ffffff;
                    border-radius: 8px;
                    padding: 40px;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                }}
                h1 {{
                    font-size: 28px;
                    color: #333;
                    font-weight: bold;
                    text-align: center;
                }}
                p {{
                    font-size: 16px;
                    line-height: 1.6;
                    color: #666;
                    text-align: center;
                }}
                .cta {{
                    display: block;
                    width: 100%;
                    text-align: center;
                    padding: 15px 20px;
                    margin-top: 30px;
                    background-color: #333;
                    color: #fff;
                    text-decoration: none;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 5px;
                    transition: background-color 0.3s;
                }}
                .cta:hover {{
                    background-color: #f4c542;  /* Gold for hover effect */
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>Thank You for Subscribing!</h1>
                <p>Dear Subscriber,</p>
                <p>We are thrilled to have you on board. Thank you for subscribing to our newsletter. You will now receive exclusive updates, offers, and insights from us!</p>
                <p>We value your subscription and look forward to staying connected with you.</p>
                <a href="https://yourwebsite.com" class="cta">Visit Our Website</a>
            </div>
        </body>
    </html>
    """

    msg = Message(subject, recipients=[email])
    msg.html = html_body
    msg.sender = f"{sender_name} <no-reply@BARF-E-ZAAR.com>"

    try:
        mail.send(msg)
        print(f"Confirmation email sent to {email} successfully!")
    except Exception as e:
        print(f"Error sending confirmation email to {email}: {e}")

    
def send_contact_email(name, email, subject, message):
    msg = Message(
        subject=f"📨 Contact Form Submission: {subject}",
        recipients=[current_app.config["CONTACT_EMAIL"]],
    )

    # Fix: Preprocess the message
    formatted_message = message.replace("\n", "<br>")

    msg.html = f"""
    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f8f8; padding: 30px; color: #333;">
        <div style="max-width: 600px; margin: auto; background-color: #fff; border-radius: 12px; padding: 30px; box-shadow: 0 0 15px rgba(0,0,0,0.1);">
            <h2 style="color: #2c3e50; text-align: center; border-bottom: 2px solid #eaeaea; padding-bottom: 10px;">
                ✨ New Contact Message
            </h2>
            <p><strong style="color:#555;">Name:</strong> {name}</p>
            <p><strong style="color:#555;">Email:</strong> <a href="mailto:{email}" style="color: #3498db;">{email}</a></p>
            <p><strong style="color:#555;">Subject:</strong> {subject}</p>
            <div style="margin-top: 20px;">
                <strong style="color:#555;">Message:</strong>
                <div style="margin-top: 10px; padding: 15px; background-color: #f2f2f2; border-radius: 8px; line-height: 1.6;">
                    {formatted_message}
                </div>
            </div>
            <p style="text-align: center; font-size: 12px; color: #aaa; margin-top: 30px;">This message was sent from your website's contact form.</p>
        </div>
    </div>
    """

    mail.send(msg)


