from app import app, db
from Models import User


with app.app_context():

    user_id = 1

    user = User.query.get(user_id)

    if user:
        user.is_admin = True
        db.session.commit()
        print(f"User {user_id} has been updated to admin.")
    else:
        print(f"User with ID {user_id} not found.")
